#!/usr/bin/env python3
"""
Alkeyword prototype — Stage 1: CRAWL + claim extraction.

Input: a bare domain. Output: a claim graph + the "free findings" from spec §1.7.

Stdlib only. No install step.

NOTE ON FIDELITY: claim extraction here is deterministic/heuristic (regex + structure)
so the *shape* of the graph is inspectable and the pipeline is verifiable without
spending tokens. Production extraction (spec §1.4) would be LLM-based and would
resolve subjects properly. This prototype answers "what does the raw material on a
real site actually look like?", not "is the extractor good?".

Usage:
    python3 crawl.py <domain> [--max-pages N] [--json out.json] [--delay S]
"""

import argparse
import gzip
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from html.parser import HTMLParser

UA = "AlkeywordBot/0.1 (+https://alkeyword.com; site-owner analysis)"

AI_CRAWLERS = [
    "GPTBot", "ClaudeBot", "Claude-Web", "PerplexityBot",
    "OAI-SearchBot", "Google-Extended", "CCBot", "anthropic-ai",
]

SKIP_EXT = re.compile(
    r"\.(pdf|zip|tar|gz|png|jpe?g|gif|svg|webp|ico|mp4|mp3|css|js|json|xml|woff2?|ttf)$", re.I
)

# ---------------------------------------------------------------- data model


@dataclass
class Page:
    url: str
    status: int = 0
    title: str = ""
    meta_description: str = ""
    lang: str = ""
    outline: list = field(default_factory=list)      # [(level, text)]
    blocks: list = field(default_factory=list)       # [(tag, text)]
    body_text: str = ""
    schema_blocks: list = field(default_factory=list)
    internal_links_out: list = field(default_factory=list)
    external_links_out: list = field(default_factory=list)
    images_no_alt: int = 0
    word_count: int = 0
    render_mode: str = "static"
    needs_headless: bool = False


@dataclass
class Claim:
    id: str
    type: str
    subject: str
    predicate: str
    object: str
    text_span: str
    source_url: str
    source_anchor: str
    confidence: float


# ---------------------------------------------------------------- html parsing

BLOCK_TAGS = {"p", "li", "td", "th", "dd", "dt", "blockquote", "figcaption",
              "h1", "h2", "h3", "h4", "h5", "h6", "div", "section", "article"}


class Extractor(HTMLParser):
    """Collects headings, block-level text, JSON-LD, links, meta."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.title = ""
        self.meta_description = ""
        self.lang = ""
        self.outline = []
        self.blocks = []          # (tag, text)
        self.schema_blocks = []
        self.links = []
        self.images_no_alt = 0
        self.has_script = False

        self._skip_depth = 0      # inside script/style/nav-ish
        self._in_title = False
        self._in_ld = False
        self._ld_buf = []
        self._cur_tag = None
        self._buf = []

    # -- helpers
    def _flush(self):
        if self._cur_tag and self._buf:
            text = re.sub(r"\s+", " ", "".join(self._buf)).strip()
            if text:
                if self._cur_tag.startswith("h") and len(self._cur_tag) == 2:
                    self.outline.append((int(self._cur_tag[1]), text))
                self.blocks.append((self._cur_tag, text))
        self._buf = []
        self._cur_tag = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in ("script", "style", "noscript"):
            if tag == "script":
                self.has_script = True
                if a.get("type", "").lower() == "application/ld+json":
                    self._in_ld = True
                    self._ld_buf = []
                    return
            self._skip_depth += 1
            return
        if self._skip_depth:
            return

        if tag == "html":
            self.lang = a.get("lang", "")
        elif tag == "title":
            self._in_title = True
        elif tag == "meta":
            name = (a.get("name") or a.get("property") or "").lower()
            if name in ("description", "og:description") and not self.meta_description:
                self.meta_description = a.get("content", "").strip()
        elif tag == "a" and a.get("href"):
            self.links.append(a["href"].strip())
        elif tag == "img":
            if not a.get("alt", "").strip():
                self.images_no_alt += 1
        elif tag in BLOCK_TAGS:
            self._flush()
            self._cur_tag = tag
        elif tag in ("br",):
            self._buf.append(" ")

    def handle_endtag(self, tag):
        if tag == "script" and self._in_ld:
            raw = "".join(self._ld_buf).strip()
            if raw:
                try:
                    self.schema_blocks.append(json.loads(raw))
                except Exception:
                    pass
            self._in_ld = False
            return
        if tag in ("script", "style", "noscript"):
            self._skip_depth = max(0, self._skip_depth - 1)
            return
        if self._skip_depth:
            return
        if tag == "title":
            self._in_title = False
        elif tag in BLOCK_TAGS and tag == self._cur_tag:
            self._flush()

    def handle_data(self, data):
        if self._in_ld:
            self._ld_buf.append(data)
            return
        if self._skip_depth:
            return
        if self._in_title:
            self.title += data
        elif self._cur_tag:
            self._buf.append(data)

    def close(self):
        super().close()
        self._flush()


# ---------------------------------------------------------------- fetching


def fetch(url, timeout=20):
    req = urllib.request.Request(
        url, headers={"User-Agent": UA, "Accept-Encoding": "gzip", "Accept": "text/html,*/*"}
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            if r.headers.get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            ctype = r.headers.get("Content-Type", "")
            charset = "utf-8"
            m = re.search(r"charset=([\w-]+)", ctype, re.I)
            if m:
                charset = m.group(1)
            return r.status, ctype, raw.decode(charset, errors="replace"), r.url
    except urllib.error.HTTPError as e:
        return e.code, "", "", url
    except Exception:
        return 0, "", "", url


def normalize_url(url):
    """Canonicalize so bare-origin and origin+'/' aren't counted as two pages.

    Without this, inbound-link counts undercount and every homepage looks
    orphaned. Found by comparing a live crawl against the raw href dump.
    """
    url, _ = urllib.parse.urldefrag(url)
    p = urllib.parse.urlsplit(url)
    path = p.path or "/"
    if path != "/" and path.endswith("/"):
        path = path.rstrip("/")
    netloc = p.netloc.lower()
    if netloc.endswith(":443") and p.scheme == "https":
        netloc = netloc[:-4]
    return urllib.parse.urlunsplit((p.scheme, netloc, path, p.query, ""))


def check_robots(origin):
    """Returns (blocked_ai_crawlers, sitemaps)."""
    status, _, body, _ = fetch(urllib.parse.urljoin(origin, "/robots.txt"))
    if status != 200 or not body:
        return [], []
    sitemaps = re.findall(r"(?im)^\s*sitemap:\s*(\S+)", body)
    blocked, cur = [], []
    for line in body.splitlines():
        line = line.split("#")[0].strip()
        if not line:
            continue
        k, _, v = line.partition(":")
        k, v = k.strip().lower(), v.strip()
        if k == "user-agent":
            cur.append(v)
        elif k == "disallow" and v == "/":
            for agent in cur:
                if agent in AI_CRAWLERS or agent == "*":
                    blocked.append(agent)
            cur = []
        elif k == "allow":
            cur = []
    return sorted(set(blocked)), sitemaps


def urls_from_sitemap(sm_url, origin, depth=0, seen=None):
    if depth > 2:
        return []
    seen = seen if seen is not None else set()
    if sm_url in seen:
        return []
    seen.add(sm_url)
    status, _, body, _ = fetch(sm_url)
    if status != 200 or not body:
        return []
    locs = re.findall(r"<loc>\s*([^<]+?)\s*</loc>", body, re.I)
    if "<sitemapindex" in body.lower():
        out = []
        for loc in locs[:20]:
            out.extend(urls_from_sitemap(loc, origin, depth + 1, seen))
        return out
    return [u for u in locs if u.startswith(origin)]


# ---------------------------------------------------------------- claims

SENT_SPLIT = re.compile(r"(?<=[.!?])\s+(?=[A-Z\"'(])")
QUANTITY = re.compile(
    r"(?:[$£€]\s?\d[\d,]*(?:\.\d+)?(?:\s?[kKmMbB])?"          # currency
    r"|\d[\d,]*(?:\.\d+)?\s?%"                                  # percent
    r"|\b\d[\d,]*(?:\.\d+)?\s?(?:x|×)\b"                        # multiplier
    r"|\b\d{4}\b(?=\s|,|\.|$)"                                  # year
    r"|\b\d[\d,]*(?:\.\d+)?\s?(?:ms|s|sec|min|hours?|days?|weeks?|months?|years?"
    r"|GB|MB|TB|KB|req/s|ops/s|users?|customers?|companies|teams?|countries|languages?"
    r"|tests?|laws?|nodes?|pages?|projects?|models?)\b)"
)
DEFINITION = re.compile(
    r"^(?P<subj>[A-Z][\w &./'\-]{2,60}?)\s+(?P<pred>is an?|is the|refers to|means|stands for)\s+(?P<obj>.{15,300})$"
)
COMPARISON = re.compile(r"\b(?:vs\.?|versus|compared (?:to|with)|unlike|instead of|rather than|better than|faster than)\b", re.I)
CREDENTIAL = re.compile(
    r"\b(?:ISO\s?\d+|SOC\s?2|HIPAA|GDPR|PCI[- ]DSS|certified|accredited|award[- ]winning|"
    r"trusted by|partnered with|backed by|patent(?:ed)?|open[- ]source|MIT[- ]licen[cs]ed)\b", re.I
)
PROCESS_STEP = re.compile(r"^(?:step\s*\d+|\d+[.)]\s|first|second|third|then|next|finally)\b", re.I)
QUOTE = re.compile(r"[“\"](.{25,400}?)[”\"]")
BOILERPLATE = re.compile(
    r"^(?:copyright|©|all rights reserved|privacy policy|terms|cookie|sign in|log in|"
    r"menu|skip to|subscribe|follow us|share|back to top)\b", re.I
)


def sentences(text):
    for s in SENT_SPLIT.split(text):
        s = s.strip()
        if 20 <= len(s) <= 400 and not BOILERPLATE.match(s):
            yield s


def extract_claims(page, entity_name, seq):
    """Heuristic claim extraction. Returns list[Claim]."""
    claims = []
    anchor_stack = {}

    def anchor_for(i):
        # nearest preceding heading
        best = ""
        for lvl, txt in page.outline:
            best = txt
        return best[:80]

    def add(ctype, subj, pred, obj, span, conf):
        seq[0] += 1
        claims.append(Claim(
            id=f"c{seq[0]:04d}", type=ctype, subject=subj or entity_name,
            predicate=pred, object=obj[:200], text_span=span[:300],
            source_url=page.url, source_anchor=anchor_for(0), confidence=conf,
        ))

    # -- from JSON-LD (highest confidence)
    for block in page.schema_blocks:
        for node in _iter_ld(block):
            t = node.get("@type")
            t = t[0] if isinstance(t, list) and t else t
            if not isinstance(t, str):
                continue
            if t in ("Organization", "Corporation", "LocalBusiness", "Product", "SoftwareApplication"):
                nm = node.get("name")
                if isinstance(nm, str):
                    add("entity", nm, "is_a", t, f"schema:{t} name={nm}", 0.95)
                desc = node.get("description")
                if isinstance(desc, str) and len(desc) > 20:
                    add("attribute", nm or entity_name, "described_as", desc, desc, 0.9)
            elif t == "FAQPage":
                for q in node.get("mainEntity", []) or []:
                    if isinstance(q, dict) and isinstance(q.get("name"), str):
                        add("question", entity_name, "answers", q["name"], q["name"], 0.95)
            elif t == "DefinedTerm" and isinstance(node.get("name"), str):
                add("definition", node["name"], "defined_as",
                    str(node.get("description", ""))[:200], node["name"], 0.95)
            elif t == "HowTo":
                steps = node.get("step", []) or []
                if len(steps) >= 3:
                    add("process", node.get("name", entity_name), "has_steps",
                        f"{len(steps)} steps", str(node.get("name", ""))[:200], 0.95)

    # -- headings that are questions
    for lvl, txt in page.outline:
        if txt.rstrip().endswith("?") and len(txt) > 10:
            add("question", entity_name, "answers", txt, txt, 0.8)

    # -- block-level
    ordered_steps = 0
    for tag, text in page.blocks:
        if BOILERPLATE.match(text) or len(text) < 15:
            continue

        if tag == "blockquote" and len(text) > 25:
            add("quote", entity_name, "quotes", text, text, 0.85)
            continue

        if tag == "li" and PROCESS_STEP.match(text):
            ordered_steps += 1

        for sent in sentences(text):
            fired = False

            m = DEFINITION.match(sent)
            if m and len(m.group("subj").split()) <= 6:
                add("definition", m.group("subj"), "defined_as", m.group("obj"), sent, 0.7)
                fired = True

            qs = QUANTITY.findall(sent)
            if qs:
                add("quantity", entity_name, "states_quantity", ", ".join(qs[:4]), sent, 0.75)
                fired = True

            if COMPARISON.search(sent):
                add("comparison", entity_name, "compares", sent, sent, 0.65)
                fired = True

            if CREDENTIAL.search(sent):
                add("credential", entity_name, "claims_credential",
                    CREDENTIAL.search(sent).group(0), sent, 0.7)
                fired = True

            for q in QUOTE.findall(sent):
                add("quote", entity_name, "quotes", q, sent, 0.6)
                fired = True

            if not fired and tag in ("p", "li") and len(sent) > 40:
                add("attribute", entity_name, "asserts", sent, sent, 0.4)

    if ordered_steps >= 3:
        add("process", entity_name, "has_steps", f"{ordered_steps} ordered steps",
            f"{ordered_steps} step-like list items", 0.6)

    return claims


def _iter_ld(node):
    if isinstance(node, dict):
        if "@graph" in node:
            for n in node["@graph"]:
                yield from _iter_ld(n)
        yield node
        for v in node.values():
            if isinstance(v, (dict, list)):
                yield from _iter_ld(v)
    elif isinstance(node, list):
        for n in node:
            yield from _iter_ld(n)


# ---------------------------------------------------------------- findings


def find_contradictions(claims):
    """Same normalized quantity subject, different values."""
    out = []
    by_ctx = defaultdict(list)
    for c in claims:
        if c.type != "quantity":
            continue
        # context key = the non-numeric words around the number
        key = " ".join(sorted(set(
            w.lower() for w in re.findall(r"[a-zA-Z]{4,}", c.text_span)
        )))[:120]
        if key:
            by_ctx[key].append(c)
    for key, group in by_ctx.items():
        vals = {c.object for c in group}
        urls = {c.source_url for c in group}
        if len(vals) > 1 and len(urls) > 1:
            out.append({"context": key[:80], "values": sorted(vals)[:4],
                        "sources": sorted(urls)[:4]})
    return out[:15]


def find_orphans(pages, claims):
    inbound = defaultdict(int)
    for p in pages.values():
        for l in set(p.internal_links_out):
            if l != p.url:
                inbound[l] += 1
    high_value = defaultdict(int)
    for c in claims:
        if c.type in ("quantity", "quote", "definition", "credential", "process"):
            high_value[c.source_url] += 1
    return sorted(
        [{"url": u, "inbound_links": inbound.get(u, 0), "high_value_claims": n}
         for u, n in high_value.items() if inbound.get(u, 0) <= 1 and n >= 2],
        key=lambda d: -d["high_value_claims"],
    )[:15]


def find_duplicate_urls(pages):
    """Same body text served at >1 URL.

    Reports the duplication only. The crawler does not parse <link rel="canonical">,
    so it cannot report whether one is present — saying "no canonical" here would be
    a conclusion with no observation under it.

    Splits the entity's authority across URLs and gives engines competing
    candidates to cite. Surfaced by real input on the first live run.
    """
    by_text = defaultdict(list)
    for p in pages.values():
        if p.word_count >= 50:
            key = re.sub(r"\s+", " ", p.body_text[:1500]).strip().lower()
            by_text[key].append(p.url)
    return [{"urls": sorted(u), "count": len(u)}
            for u in by_text.values() if len(u) > 1][:15]


def find_unsourced_quantities(pages, claims):
    """Quantity claims on pages with no outbound external links = no citation."""
    out = []
    for c in claims:
        if c.type != "quantity":
            continue
        p = pages.get(c.source_url)
        if p and len(p.external_links_out) == 0:
            out.append({"claim": c.text_span[:140], "source": c.source_url})
    return out[:15]


# ---------------------------------------------------------------- crawl loop


def crawl(domain, max_pages=60, delay=0.4, verbose=True):
    if not domain.startswith("http"):
        domain = "https://" + domain
    parts = urllib.parse.urlsplit(domain)
    origin = f"{parts.scheme}://{parts.netloc}"
    host = parts.netloc

    blocked, sitemaps = check_robots(origin)

    queue, seen = [origin + "/"], set()
    for sm in sitemaps[:5]:
        for u in urls_from_sitemap(sm, origin):
            if u not in queue:
                queue.append(u)

    pages, order = {}, 0
    while queue and len(pages) < max_pages:
        url = normalize_url(queue.pop(0))
        if url in seen or SKIP_EXT.search(url):
            continue
        seen.add(url)

        status, ctype, body, final = fetch(url)
        if status != 200 or "html" not in ctype.lower():
            continue

        ex = Extractor()
        try:
            ex.feed(body)
            ex.close()
        except Exception:
            pass

        text = " ".join(t for tag, t in ex.blocks if tag in ("p", "li", "td", "dd", "blockquote"))
        pg = Page(
            url=url, status=status, title=ex.title.strip()[:200],
            meta_description=ex.meta_description[:300], lang=ex.lang,
            outline=ex.outline[:60], blocks=ex.blocks, body_text=text[:60000],
            schema_blocks=ex.schema_blocks, images_no_alt=ex.images_no_alt,
            word_count=len(text.split()),
        )
        pg.needs_headless = pg.word_count < 100 and ex.has_script

        for href in ex.links:
            try:
                absu = normalize_url(urllib.parse.urljoin(url, href))
            except Exception:
                continue
            if not absu.startswith("http"):
                continue
            if urllib.parse.urlsplit(absu).netloc == host:
                pg.internal_links_out.append(absu)
                if absu not in seen and len(pages) + len(queue) < max_pages * 4:
                    queue.append(absu)
            else:
                pg.external_links_out.append(absu)

        pages[url] = pg
        order += 1
        if verbose:
            flag = " [SPA?]" if pg.needs_headless else ""
            print(f"  [{order:>3}] {pg.word_count:>5}w  {url[:78]}{flag}", file=sys.stderr)
        time.sleep(delay)

    # entity inference — ordered by reliability
    home = pages.get(origin + "/") or (next(iter(pages.values())) if pages else None)

    def name_like(s):
        """Reject taglines/sentences. An entity name is a name, not a claim."""
        if not s:
            return False
        s = s.strip()
        return (2 < len(s) < 60 and len(s.split()) <= 6
                and ". " not in s and not s.endswith(".")
                and not s.endswith("?"))

    entity = host.split(".")[0]
    if home:
        # 1. schema.org Organization/Product name — highest confidence
        for block in home.schema_blocks:
            for node in _iter_ld(block):
                t = node.get("@type")
                t = t[0] if isinstance(t, list) and t else t
                if t in ("Organization", "Corporation", "LocalBusiness",
                         "Product", "SoftwareApplication", "WebSite"):
                    if name_like(node.get("name")):
                        entity = node["name"].strip()
                        break
            else:
                continue
            break
        else:
            # 2. leading segment of <title> before a separator
            cand = re.split(r"\s[–—|·:-]\s", home.title)[0].strip() if home.title else ""
            if name_like(cand):
                entity = cand
            else:
                # 3. an h1 only if it reads as a name, not a tagline
                for lvl, txt in home.outline:
                    if lvl == 1 and name_like(txt):
                        entity = txt.strip()
                        break

    seq = [0]
    claims = []
    for p in pages.values():
        claims.extend(extract_claims(p, entity, seq))

    return {
        "domain": host, "origin": origin, "entity": entity,
        "robots_blocked_ai_crawlers": blocked, "sitemaps_found": sitemaps[:5],
        "pages": pages, "claims": claims,
        "findings": {
            "contradictions": find_contradictions(claims),
            "orphans": find_orphans(pages, claims),
            "duplicate_urls": find_duplicate_urls(pages),
            "unsourced_quantities": find_unsourced_quantities(pages, claims),
            "spa_pages": [p.url for p in pages.values() if p.needs_headless],
            "pages_without_schema": [p.url for p in pages.values() if not p.schema_blocks],
        },
    }


# ---------------------------------------------------------------- report


def report(r):
    pages, claims = r["pages"], r["claims"]
    by_type = defaultdict(list)
    for c in claims:
        by_type[c.type].append(c)

    W = 74
    print("\n" + "=" * W)
    print(f"  ALKEYWORD — STAGE 1 CRAWL   ·   {r['domain']}")
    print("=" * W)
    print(f"  Entity inferred : {r['entity']}")
    print(f"  Pages crawled   : {len(pages)}")
    print(f"  Total words     : {sum(p.word_count for p in pages.values()):,}")
    print(f"  Claims extracted: {len(claims)}")
    print(f"  Sitemaps        : {len(r['sitemaps_found'])}")

    print("\n  CLAIM GRAPH BY TYPE")
    print("  " + "-" * (W - 4))
    order = ["entity", "quantity", "quote", "definition", "comparison",
             "question", "credential", "process", "attribute"]
    lever = {"quantity": " ← strongest citation lever",
             "quote": " ← 2nd strongest lever",
             "definition": " ← mintable: glossary",
             "comparison": " ← mintable: comparison page",
             "question": " ← mintable: FAQ",
             "process": " ← mintable: how-it-works"}
    for t in order:
        n = len(by_type.get(t, []))
        bar = "█" * min(38, n)
        print(f"  {t:<11} {n:>5}  {bar}{lever.get(t, '') if n else ''}")

    # material sufficiency (spec §4.2)
    print("\n  MATERIAL SUFFICIENCY — what could be minted (spec §4.2)")
    print("  " + "-" * (W - 4))
    q, qt, d, cmp_, ques, cred, proc = (
        len(by_type["quantity"]), len(by_type["quote"]), len(by_type["definition"]),
        len(by_type["comparison"]), len(by_type["question"]), len(by_type["credential"]),
        len(by_type["process"]),
    )
    forms = [
        ("Statistics / data page", q >= 5, f"{q}/5 quantity claims"),
        ("Glossary / definitions", d >= 3, f"{d}/3 definition claims"),
        ("FAQ page", ques >= 5, f"{ques}/5 question claims"),
        ("Comparison page", cmp_ >= 6, f"{cmp_}/6 comparison claims"),
        ("How-it-works explainer", proc >= 1, f"{proc}/1 process claims"),
        ("Entity / about page", cred >= 3, f"{cred}/3 credential claims"),
    ]
    for name, ok, detail in forms:
        print(f"  {'✓ MINTABLE' if ok else '✗ REFUSED '}  {name:<26} {detail}")

    f = r["findings"]
    print("\n  FREE FINDINGS — no engine calls spent (spec §1.7)")
    print("  " + "-" * (W - 4))
    if r["robots_blocked_ai_crawlers"]:
        print(f"  ⚠ robots.txt blocks AI crawlers: {', '.join(r['robots_blocked_ai_crawlers'])}")
    else:
        print("  ✓ robots.txt does not block AI crawlers")
    print(f"  · self-contradictions   : {len(f['contradictions'])}")
    print(f"  · duplicate-URL groups  : {len(f['duplicate_urls'])}")
    print(f"  · orphaned value pages  : {len(f['orphans'])}")
    print(f"  · unsourced quantities  : {len(f['unsourced_quantities'])}")
    print(f"  · SPA pages (need JS)   : {len(f['spa_pages'])}")
    print(f"  · pages with no schema  : {len(f['pages_without_schema'])}/{len(pages)}")

    if f["contradictions"]:
        print("\n  ⚠ CONTRADICTIONS (G6)")
        for c in f["contradictions"][:4]:
            print(f"    values {c['values']}  across {len(c['sources'])} pages")
            for s in c["sources"][:2]:
                print(f"      · {s[:68]}")

    if f["duplicate_urls"]:
        print("\n  ⚠ DUPLICATE CONTENT — same page, multiple URLs")
        for d in f["duplicate_urls"][:4]:
            print(f"    {d['count']} URLs serve identical content:")
            for u in d["urls"][:3]:
                print(f"      · {u[:66]}")

    if f["orphans"]:
        print("\n  ⚠ ORPHANED HIGH-VALUE PAGES (G7)")
        for o in f["orphans"][:5]:
            print(f"    {o['high_value_claims']:>3} claims · {o['inbound_links']} inbound · {o['url'][:56]}")

    print("\n  SAMPLE CLAIMS (highest-value types)")
    print("  " + "-" * (W - 4))
    for t in ("quantity", "definition", "quote", "credential"):
        for c in by_type.get(t, [])[:3]:
            print(f"  [{c.id}] {t:<10} conf={c.confidence:.2f}")
            print(f"        \"{c.text_span[:96]}\"")
            print(f"        ← {c.source_url[:64]}")
    print("=" * W + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("domain")
    ap.add_argument("--max-pages", type=int, default=60)
    ap.add_argument("--delay", type=float, default=0.4)
    ap.add_argument("--json")
    a = ap.parse_args()

    print(f"crawling {a.domain} (max {a.max_pages} pages)...", file=sys.stderr)
    r = crawl(a.domain, a.max_pages, a.delay)
    report(r)

    if a.json:
        with open(a.json, "w") as fh:
            json.dump({
                "domain": r["domain"], "entity": r["entity"],
                "robots_blocked_ai_crawlers": r["robots_blocked_ai_crawlers"],
                "pages": [{k: v for k, v in asdict(p).items() if k != "body_text"}
                          for p in r["pages"].values()],
                "claims": [asdict(c) for c in r["claims"]],
                "findings": r["findings"],
            }, fh, indent=2)
        print(f"wrote {a.json}", file=sys.stderr)


if __name__ == "__main__":
    main()
