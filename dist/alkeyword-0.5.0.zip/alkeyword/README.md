# Alkeyword

Bring a domain name. Nothing else.

Alkeyword crawls the site, builds a graph of every claim it already makes, measures what AI
engines actually say about it, and transmutes those existing claims into the page forms AI
answers cite — with every factual sentence traceable back to the site's own words.

**Transmute, never fabricate.** If the site doesn't contain the raw material to ground a page,
Alkeyword refuses to write it and tells you what's missing.

---

## Install

```bash
./install.sh
```

Then start a new Claude Code session:

```
/alkeyword example.com
```

`--project` installs into `./.claude/skills` for one repo instead of your user account.

**Requirements:** Claude Code, and `python3` (stdlib only — nothing to `pip install`).

---

## What it costs

| Stage | Runs on | Cost |
|---|---|---|
| Crawl, claim graph, free findings | Your machine, plain Python | **Nothing** |
| Claim extraction, probing, generation | Your Claude subscription | Subscription usage |

There are no API keys to paste and no per-token bill. The expensive-to-compute parts are
deterministic code, not model calls — the model is used where judgment is actually needed.

Probing covers the web-search surface your Claude session can reach. That's **one engine.**
Cross-engine citation overlap is only about 11%, so it tells you nothing about ChatGPT,
Perplexity, or Google AI Overviews. Multi-engine coverage needs your own API keys and real
per-probe cost; Alkeyword will tell you the tradeoff rather than quietly spending or quietly
skipping.

---

## What you get before any model runs

The crawl alone produces findings that cost nothing:

- **`robots.txt` blocking AI crawlers** — if `GPTBot`, `ClaudeBot`, or `PerplexityBot` are
  disallowed, the site is invisible to AI search by its own configuration. That's the whole
  answer, found in one request.
- **Self-contradictions** — the pricing page says $49, a blog post says $39.
- **Duplicate URLs** — the same page at `/thing` and `/thing.html`, splitting its authority with
  no canonical to disambiguate.
- **Orphaned value** — a page full of statistics that nothing links to.
- **Unsourced numbers** — your strongest claims, with nothing backing them.
- **Missing schema** — prose an engine can't parse as structured data.

---

## The refusal rule

Alkeyword will tell you it can't write something:

> You have 3 claims about X. A comparison page needs at least 8, including 2 quantities.
> Here's what's missing.

This is deliberate and it is the point. Google's March 2026 core update named *scaled content
abuse* specifically — sites publishing bulk AI-generated pages without editorial oversight saw
50–80% traffic drops and manual actions. Tools that generate 30 articles a month regardless of
whether there's anything real to say are selling you into that.

Output is capped at ~6 pieces per cycle, each closing a measured gap. Human review before
publishing is the default.

---

## Provenance

Every factual sentence in generated output carries the claim IDs it draws on, and each claim
points at the page and the exact text it came from. Sentences that can't be grounded are flagged
for you to fill in — never shipped silently.

---

## Publishing

Out of scope for now. Alkeyword detects your CMS during the crawl and hands off markdown or
HTML-with-schema. You publish.

---

https://alkeyword.com
