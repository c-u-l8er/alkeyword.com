#!/usr/bin/env python3
"""
Alkeyword — Stage 4: BRIEF. Turn queries + claims into work orders.

Consumes crawl.py's --json and expand.py's --json. Optionally probe.py's --json.
Emits ranked research briefs as markdown.

The rule this file exists to enforce: a brief must be specific enough that writing
from it is ASSEMBLY, NOT RESEARCH. So every brief carries the site's own claims
verbatim, with source URLs. A brief that sends the reader off to gather their own
facts is a dashboard, and dashboards are what people churn out of.

Usage:
    python3 brief.py crawl.json expand.json [--probe probe.json] [--out briefs.md]
"""

import argparse
import json
import pathlib
import re
import sys
from collections import defaultdict

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
try:
    import config as cfg_mod
    _CFG = cfg_mod.load()
except Exception:                                    # config is optional, never fatal
    _CFG = None

STOP = {"the", "and", "for", "with", "that", "this", "you", "your", "are", "not",
        "how", "what", "why", "which", "when", "does", "can", "is", "a", "an",
        "to", "of", "in", "on", "it", "be", "or", "do", "best", "vs", "who",
        "should", "will", "from", "have", "has", "was", "were", "been"}

# form -> (label, requirements, why it earns citations, citation value 1-6)
#
# `value` breaks ties among SATISFIED forms. Without it, selection collapses to
# whichever form has the loosest bar — a live run produced four briefs and all four
# came back "Glossary", which is useless as a recommendation.
FORMS = {
    "comparison": ("Comparison page",
                   {"comparison": 2, "attribute": 6, "quantity": 2},
                   "Comparison pages have the highest citation pull in AI answers.", 6),
    "statistics": ("Statistics / data page",
                   {"quantity": 5},
                   "Statistics are the strongest measured citation lever.", 5),
    "faq":        ("FAQ page",
                   {"question": 5},
                   "FAQ pages map 1:1 onto how people query engines.", 4),
    "howto":      ("How-it-works explainer",
                   {"process": 1, "attribute": 3},
                   "Process content answers the 'how does X work' query class.", 3),
    "entity":     ("Entity / about page",
                   {"credential": 3},
                   "Entity pages let engines resolve who you are at all.", 2),
    "glossary":   ("Glossary / definition page",
                   {"definition": 3, "attribute": 4},
                   "Definition pages are Wikipedia-shaped and disproportionately cited.", 1),
}

# Config may retune requirements and values — but config.py clamps anything that
# would disable the refusal rule, so a gutted form spec is restored before it lands here.
if _CFG and _CFG.get("forms"):
    for _k, _spec in _CFG["forms"].items():
        if _k in FORMS and isinstance(_spec.get("req"), dict):
            _label, _req, _why, _val = FORMS[_k]
            FORMS[_k] = (_label, _spec["req"], _why, _spec.get("value", _val))


def tokens(s):
    return {w for w in re.findall(r"[a-z][a-z\-]{2,}", s.lower()) if w not in STOP}


# ---------------------------------------------------------------- matching


def dedupe_claims(claims):
    """Collapse the same claim served at duplicate URLs.

    crawl.py already detects duplicate-URL groups (7 of them on the live test site:
    /x and /x.html). Without collapsing them, 8 of 20 claims in a brief were the same
    text twice and the raw-material section was 40% redundant. Keep the shortest URL
    as canonical and carry the duplicates so the underlying issue stays visible.
    """
    seen = {}
    for c in claims:
        key = re.sub(r"\W+", "", c["text_span"]).lower()[:120]
        if not key:
            continue
        prev = seen.get(key)
        if prev is None or len(c["source_url"]) < len(prev["source_url"]):
            if prev is not None:
                c = dict(c)
                c["also_at"] = sorted(set(prev.get("also_at", [])) | {prev["source_url"]})
            seen[key] = c
        else:
            prev.setdefault("also_at", [])
            if c["source_url"] not in prev["also_at"]:
                prev["also_at"].append(c["source_url"])
    return list(seen.values())


def match_claims(query, claims, entity_tokens):
    """Same rule as expand.py, but keeps the claim objects so briefs can carry them."""
    qt = tokens(query)
    if not qt:
        return []
    out = []
    for c in claims:
        ct = tokens(c["text_span"] + " " + str(c["object"]))
        if len((qt & ct) - entity_tokens) >= 2:
            out.append(c)
    return out


def cluster_by_claims(queries, claims, entity, min_strong=2):
    """Cluster queries by the CLAIMS they share, not by shared words.

    Two queries answered by the same claims are the same page. Word-similarity
    would split 'agent memory systems' from 'how does agent memory work' even
    though one page serves both.
    """
    et = tokens(entity)
    strong_types = {"quantity", "quote", "definition", "comparison",
                    "process", "credential"}

    enriched = []
    for q in queries:
        matched = match_claims(q["query"], claims, et)
        strong = [c for c in matched if c["type"] in strong_types]
        if len(strong) >= min_strong:
            enriched.append({"query": q, "claims": matched,
                             "ids": {c["id"] for c in matched},
                             "strong": len(strong)})

    enriched.sort(key=lambda e: -e["strong"])
    clusters = []
    for e in enriched:
        placed = False
        for cl in clusters:
            inter = len(e["ids"] & cl["ids"])
            union = len(e["ids"] | cl["ids"])
            if union and inter / union >= 0.5:
                cl["queries"].append(e["query"])
                cl["ids"] |= e["ids"]
                for c in e["claims"]:
                    cl["claims"].setdefault(c["id"], c)
                placed = True
                break
        if not placed:
            clusters.append({"queries": [e["query"]], "ids": set(e["ids"]),
                             "claims": {c["id"]: c for c in e["claims"]}})
    return clusters


# ---------------------------------------------------------------- form fit


def fit_form(claims):
    """Pick the form this material best supports, and say what's missing for it.

    Returns (key, label, why, missing[], satisfied bool). Chooses the form with the
    highest satisfaction ratio, tie-broken toward fully-satisfied forms.
    """
    have = defaultdict(int)
    for c in claims:
        have[c["type"]] += 1

    scored = []
    for key, (label, req, why, value) in FORMS.items():
        missing = [(t, n - have[t]) for t, n in req.items() if have[t] < n]
        total_req = sum(req.values())
        met = sum(min(have[t], n) for t, n in req.items())
        scored.append({"satisfied": not missing, "value": value,
                       "ratio": met / total_req, "key": key, "label": label,
                       "why": why, "missing": missing})

    # Satisfied first; among satisfied, the most valuable form — NOT the loosest.
    # Among unsatisfied, the closest to satisfied, then most valuable.
    scored.sort(key=lambda s: (s["satisfied"],
                               s["value"] if s["satisfied"] else s["ratio"],
                               s["value"]), reverse=True)
    best = scored[0]
    alts = [s["label"] for s in scored[1:] if s["satisfied"]]
    return {"key": best["key"], "label": best["label"], "why": best["why"],
            "satisfied": best["satisfied"], "ratio": round(best["ratio"], 2),
            "also_possible": alts[:3],
            "missing": [{"type": t, "need_more": n} for t, n in best["missing"]]}


def outline_for(form_key, claims):
    """Section headings, each mapped to the claim IDs that fill it."""
    by_type = defaultdict(list)
    for c in claims:
        by_type[c["type"]].append(c)

    def ids(t, n=6):
        return [c["id"] for c in by_type.get(t, [])[:n]]

    plans = {
        "comparison": [("What each one is", ids("definition") + ids("entity")),
                       ("Feature-by-feature", ids("attribute", 8)),
                       ("The numbers", ids("quantity")),
                       ("Where each wins", ids("comparison"))],
        "statistics": [("The headline figures", ids("quantity", 8)),
                       ("Method / where these come from", ids("process") + ids("credential")),
                       ("What they mean", ids("attribute", 5))],
        "glossary":   [("Definition", ids("definition", 3)),
                       ("How it works in practice", ids("attribute", 6)),
                       ("Related figures", ids("quantity", 4))],
        "faq":        [("Questions", ids("question", 10)),
                       ("Supporting detail", ids("attribute", 6))],
        "howto":      [("Overview", ids("definition", 2)),
                       ("The steps", ids("process")),
                       ("What to expect", ids("quantity", 4))],
        "entity":     [("Who we are", ids("entity") + ids("definition", 2)),
                       ("Credentials", ids("credential", 6)),
                       ("By the numbers", ids("quantity", 4))],
    }
    return [{"heading": h, "claim_ids": i} for h, i in plans.get(form_key, []) if i]


# ---------------------------------------------------------------- scoring


def score(cluster, form, probe_state):
    reach = len(cluster["queries"])
    questions = sum(1 for q in cluster["queries"] if q.get("is_question"))
    material = min(1.0, len(cluster["claims"]) / 10)
    effort = 1 + sum(m["need_more"] for m in form["missing"])
    # unproven until probed; a measured miss is the strongest possible signal
    winnability = 1.0
    if probe_state and probe_state.get("own_cited_rate") == 0:
        winnability = 1.5
    return round((reach + questions * 0.5) * material * winnability / effort, 3)


# ---------------------------------------------------------------- render


def render(crawl, briefs, unknown_terms):
    L = []
    w = L.append
    w(f"# Research briefs — {crawl['domain']}")
    w("")
    w(f"**Entity:** {crawl['entity']}  ")
    w(f"**Briefs:** {len(briefs)}  ")
    w(f"**Source:** site crawl + Google/DuckDuckGo autocomplete. No paid keyword data.")
    w("")
    w("Each brief carries the claims from your own site, verbatim, with source URLs — so")
    w("writing is assembly, not another research job. Nothing here is written for you.")
    w("")

    if unknown_terms:
        w("> ⚠️ **Autocomplete has no data for:** " +
          ", ".join(f"`{t}`" for t in unknown_terms))
        w("> Nobody is searching these terms. That's a positioning finding, not a content one —")
        w("> demand has to be captured on category language instead.")
        w("")

    ready = [b for b in briefs if b["form"]["satisfied"]]
    w(f"**{len(ready)} ready to write · {len(briefs) - len(ready)} need material first**")
    w("")
    w("---")
    w("")

    for i, b in enumerate(briefs, 1):
        f = b["form"]
        status = "READY" if f["satisfied"] else "NEEDS MATERIAL"
        w(f"## {i}. {f['label']} — {status}")
        w("")
        w(f"*Score {b['score']} · {len(b['claims'])} claims available · {f['why']}*")
        w("")

        w("### Questions this answers")
        w("")
        for q in b["questions"][:8]:
            mark = "❓" if q.get("is_question") else "🔍"
            w(f"- {mark} `{q['query']}`")
        if len(b["questions"]) > 8:
            w(f"- *…and {len(b['questions']) - 8} more in this cluster*")
        w("")

        if b.get("current_state"):
            cs = b["current_state"]
            w("### Where you stand now")
            w("")
            w(f"- Your domain cited: **{cs['own_cited']}**")
            if cs.get("competitors"):
                w(f"- Cited instead: {', '.join(cs['competitors'][:5])}")
            w(f"- Measured on: {cs['engine']} *(one engine — ~11% cross-engine overlap)*")
            w("")

        if not f["satisfied"]:
            w("### Gather this first")
            w("")
            for m in f["missing"]:
                w(f"- **{m['need_more']} more `{m['type']}`** "
                  f"{'claims' if m['need_more'] > 1 else 'claim'}")
            w("")
            w("Until then this is an opportunity, not an assignment.")
            w("")

        w("### Outline")
        w("")
        for s in b["outline"]:
            w(f"**{s['heading']}** — {', '.join(s['claim_ids'])}")
        w("")

        w("### Your raw material")
        w("")
        w("Everything below is already on your site. Assemble, don't research.")
        w("")
        by_src = defaultdict(list)
        for c in b["claims"]:
            by_src[c["source_url"]].append(c)
        for src, cs in sorted(by_src.items(), key=lambda kv: -len(kv[1])):
            w(f"**{src}**")
            w("")
            for c in cs[:8]:
                w(f"- `{c['id']}` *{c['type']}* — \"{c['text_span'][:150]}\"")
                if c.get("also_at"):
                    w(f"  <br>⚠️ also served at {', '.join(c['also_at'])} — "
                      f"duplicate URL, no canonical")
            w("")
        w("---")
        w("")

    w("*Generated by Alkeyword. The writing is yours.*")
    return "\n".join(L)


# ---------------------------------------------------------------- main


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("crawl_json")
    ap.add_argument("expand_json")
    ap.add_argument("--probe", help="optional probe.py --json output")
    ap.add_argument("--out", help="write markdown here (default stdout)")
    ap.add_argument("--json", help="also write structured briefs here")
    ap.add_argument("--max-briefs", type=int, default=8)
    a = ap.parse_args()

    with open(a.crawl_json) as f:
        crawl = json.load(f)
    with open(a.expand_json) as f:
        exp = json.load(f)

    probe = {}
    if a.probe:
        with open(a.probe) as f:
            pj = json.load(f)
        for q, runs in (pj.get("results") or {}).items():
            ok = [r for r in runs if "error" not in r]
            if ok:
                probe[q] = {
                    "own_cited_rate": sum(1 for r in ok if r["own_domain_cited"]) / len(ok),
                    "own_cited": f"{sum(1 for r in ok if r['own_domain_cited'])}/{len(ok)}",
                    "competitors": sorted({c for r in ok for c in r["competitors"]})[:6],
                    "engine": "perplexity/sonar",
                }

    clusters = cluster_by_claims(exp["queries"], crawl["claims"], crawl["entity"])
    if not clusters:
        print("No cluster had enough material to brief. Run stage 1b (LLM extraction) "
              "and re-seed stage 2a — auto-seeding is measurably unreliable.",
              file=sys.stderr)
        sys.exit(1)

    briefs = []
    for cl in clusters:
        claims = dedupe_claims(list(cl["claims"].values()))
        form = fit_form(claims)
        state = next((probe[q["query"]] for q in cl["queries"] if q["query"] in probe), None)
        briefs.append({
            "questions": cl["queries"],
            "claims": claims,
            "form": form,
            "outline": outline_for(form["key"], claims),
            "current_state": state,
            "score": score(cl, form, state),
        })

    briefs.sort(key=lambda b: (b["form"]["satisfied"], b["score"]), reverse=True)
    briefs = briefs[:a.max_briefs]

    md = render(crawl, briefs, exp.get("unknown_terms") or [])
    if a.out:
        with open(a.out, "w") as f:
            f.write(md)
        print(f"wrote {a.out}  ({len(briefs)} briefs)", file=sys.stderr)
    else:
        print(md)

    if a.json:
        with open(a.json, "w") as f:
            json.dump({"domain": crawl["domain"], "briefs": briefs}, f, indent=2)
        print(f"wrote {a.json}", file=sys.stderr)


if __name__ == "__main__":
    main()
