#!/usr/bin/env python3
"""
Alkeyword — state layer. Projects, run history, brief status, probe baselines.

Without this every run is one-shot and spec stage 5 (re-probe, rate deltas,
calibration) is impossible — there is nowhere to keep a baseline. This is that
somewhere.

Local only. A directory of JSON under ~/.alkeyword. No server, no account, no
network. Your research stays on your machine.

    store.py add <domain>
    store.py list
    store.py record <domain> --crawl f.json [--expand f] [--probe f] [--briefs f]
    store.py briefs <domain> [--status new|writing|written|published|dropped]
    store.py set-status <domain> <brief_id> <status> [--note "..."]
    store.py movement <domain>          # stage 5: what changed since last probe
    store.py history <domain>
"""

import argparse
import json
import os
import pathlib
import re
import shutil
import sys
from datetime import datetime, timezone

ROOT = pathlib.Path(os.environ.get("ALKEYWORD_HOME",
                                   pathlib.Path.home() / ".alkeyword"))
STATUSES = ["new", "writing", "written", "published", "dropped"]


def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def stamp():
    return datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")


def slug(domain):
    return re.sub(r"[^a-z0-9.-]", "_", domain.lower().strip())


def read(path, default=None):
    try:
        with open(path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def write(path, data):
    """Atomic — a half-written registry loses every project you've tracked."""
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, path)


def registry():
    return read(ROOT / "projects.json", {"projects": {}})


def proj_dir(domain):
    return ROOT / slug(domain)


# ---------------------------------------------------------------- commands


def cmd_add(a):
    reg = registry()
    d = slug(a.domain)
    if d in reg["projects"]:
        print(f"{d} is already tracked.")
        return
    reg["projects"][d] = {"domain": d, "added": now(), "entity": None,
                          "vertical": getattr(a, "vertical", None),
                          "last_run": None, "runs": 0}
    write(ROOT / "projects.json", reg)
    (proj_dir(d) / "runs").mkdir(parents=True, exist_ok=True)
    print(f"tracking {d}\n  {proj_dir(d)}")


def cmd_list(a):
    reg = registry()
    if not reg["projects"]:
        print("No projects yet.  store.py add <domain>")
        return
    print(f"{'DOMAIN':<32} {'ENTITY':<24} {'RUNS':>5}  LAST RUN")
    print("-" * 78)
    for p in sorted(reg["projects"].values(), key=lambda p: p["domain"]):
        print(f"{p['domain']:<32} {(p.get('entity') or '—')[:23]:<24} "
              f"{p.get('runs', 0):>5}  {p.get('last_run') or '—'}")


def cmd_record(a):
    """Snapshot a run. Files are copied in, so /tmp getting cleared doesn't matter."""
    reg = registry()
    d = slug(a.domain)
    if d not in reg["projects"]:
        cmd_add(argparse.Namespace(domain=d))
        reg = registry()

    # Run IDs are second-resolution, so two records in the same second collided and
    # the second silently overwrote the first's manifest — losing a whole run while
    # the registry still counted it. Uniquify instead.
    base_id = stamp()
    run_id, n = base_id, 1
    while (proj_dir(d) / "runs" / run_id).exists():
        n += 1
        run_id = f"{base_id}-{n}"
    rd = proj_dir(d) / "runs" / run_id
    rd.mkdir(parents=True, exist_ok=False)

    recorded, entity = {}, None
    for kind in ("crawl", "expand", "probe", "briefs"):
        src = getattr(a, kind, None)
        if not src:
            continue
        if not os.path.exists(src):
            print(f"warning: {kind} file not found: {src}", file=sys.stderr)
            continue
        shutil.copy(src, rd / f"{kind}.json")
        recorded[kind] = f"{kind}.json"
        if kind == "crawl":
            entity = (read(src, {}) or {}).get("entity")

    if not recorded:
        print("Nothing recorded — pass at least one of --crawl/--expand/--probe/--briefs",
              file=sys.stderr)
        rd.rmdir()
        sys.exit(1)

    write(rd / "manifest.json", {"run_id": run_id, "at": now(), "files": recorded})

    # Briefs get their own tracked identity so status survives regeneration.
    if "briefs" in recorded:
        merge_briefs(d, read(rd / "briefs.json", {}) or {}, run_id)

    # Probe results become the baseline for stage 5.
    if "probe" in recorded:
        record_baseline(d, read(rd / "probe.json", {}) or {}, run_id)

    p = reg["projects"][d]
    p["last_run"] = now()
    p["runs"] = p.get("runs", 0) + 1
    if entity:
        p["entity"] = entity
    write(ROOT / "projects.json", reg)

    print(f"recorded run {run_id} for {d}: {', '.join(recorded)}")


def brief_key(b):
    """Stable identity across regenerations.

    Briefs are recomputed from scratch every run, so a positional index would
    reassign statuses to the wrong brief. Key on the claim set instead — that is
    what actually defines the page.
    """
    ids = sorted(c["id"] for c in b.get("claims", []))
    if ids:
        return "c:" + "-".join(ids[:6])
    qs = sorted(q["query"] for q in b.get("questions", []))
    return "q:" + re.sub(r"\W+", "", "".join(qs[:3]))[:48]


def merge_briefs(domain, briefs_json, run_id):
    path = proj_dir(domain) / "briefs.json"
    store = read(path, {"briefs": {}})
    for b in briefs_json.get("briefs", []):
        k = brief_key(b)
        prev = store["briefs"].get(k, {})
        store["briefs"][k] = {
            "key": k,
            "form": b["form"]["label"],
            "form_key": b["form"].get("key"),
            "satisfied": b["form"]["satisfied"],
            "score": b.get("score"),
            # ALL questions, not a preview slice — calibration links a published
            # brief back to the exact questions it targeted, so truncating here
            # silently shrinks the sample it can measure.
            "questions": [q["query"] for q in b.get("questions", [])],
            "claim_count": len(b.get("claims", [])),
            "first_seen": prev.get("first_seen", now()),
            "last_seen": now(),
            "last_run": run_id,
            "status": prev.get("status", "new"),      # survives regeneration
            "note": prev.get("note"),
            "seen_count": prev.get("seen_count", 0) + 1,
        }
    write(path, store)


def record_baseline(domain, probe_json, run_id):
    """Append per-question citation rates. This is what makes stage 5 possible."""
    path = proj_dir(domain) / "baselines.json"
    base = read(path, {"questions": {}})
    qtext = {q["id"]: q["text"] for q in probe_json.get("questions", [])}

    for qid, runs in (probe_json.get("results") or {}).items():
        ok = [r for r in runs if "error" not in r]
        if not ok:
            continue
        entry = base["questions"].setdefault(
            qtext.get(qid, qid), {"history": []})
        entry["history"].append({
            "run_id": run_id, "at": now(), "n": len(ok),
            "cited": sum(1 for r in ok if r.get("own_domain_cited")),
            "named": sum(1 for r in ok if r.get("brand_mentioned")),
            "competitors": sorted({c for r in ok for c in r.get("competitors", [])})[:6],
        })
    write(path, base)


def cmd_briefs(a):
    store = read(proj_dir(a.domain) / "briefs.json", {"briefs": {}})
    rows = list(store["briefs"].values())
    if a.status:
        rows = [r for r in rows if r["status"] == a.status]
    if not rows:
        print("No briefs recorded. Run brief.py, then: store.py record <domain> --briefs f.json")
        return
    rows.sort(key=lambda r: (r["status"] != "new", -(r.get("score") or 0)))
    print(f"{'STATUS':<11} {'FORM':<28} {'SCORE':>7}  KEY")
    print("-" * 78)
    for r in rows:
        mark = "" if r["satisfied"] else "  (needs material)"
        print(f"{r['status']:<11} {r['form'][:27]:<28} {r.get('score') or 0:>7}  {r['key'][:26]}")
        if r["questions"]:
            print(f"            {r['questions'][0][:60]}{mark}")
        if r.get("note"):
            print(f"            note: {r['note']}")


def cmd_set_status(a):
    path = proj_dir(a.domain) / "briefs.json"
    store = read(path, {"briefs": {}})
    matches = [k for k in store["briefs"] if k.startswith(a.brief_id)]
    if not matches:
        print(f"No brief matching {a.brief_id!r}. Try: store.py briefs {a.domain}",
              file=sys.stderr)
        sys.exit(1)
    if len(matches) > 1:
        print(f"Ambiguous — {len(matches)} briefs match {a.brief_id!r}", file=sys.stderr)
        sys.exit(1)
    b = store["briefs"][matches[0]]
    b["status"] = a.status
    if a.note:
        b["note"] = a.note
    b["status_changed"] = now()
    write(path, store)
    print(f"{matches[0][:26]} → {a.status}")


def cmd_movement(a):
    """Stage 5. Compare the two most recent probes per question."""
    base = read(proj_dir(a.domain) / "baselines.json", {"questions": {}})
    if not base["questions"]:
        print("No probe baselines recorded yet.")
        return

    moved, flat, single = [], [], 0
    for q, entry in base["questions"].items():
        h = entry["history"]
        if len(h) < 2:
            single += 1
            continue
        prev, cur = h[-2], h[-1]
        pr, cr = prev["cited"] / prev["n"], cur["cited"] / cur["n"]
        row = (q, f"{prev['cited']}/{prev['n']}", f"{cur['cited']}/{cur['n']}", cr - pr)
        (moved if abs(cr - pr) > 1e-9 else flat).append(row)

    print(f"MOVEMENT — {a.domain}")
    print("-" * 78)
    if single and not moved and not flat:
        print(f"{single} questions have only one probe. Re-probe to compare.")
        return

    for q, p, c, delta in sorted(moved, key=lambda r: -r[3]):
        arrow = "↑" if delta > 0 else "↓"
        print(f"  {arrow} {p} → {c}   {q[:56]}")
    if flat:
        print(f"\n  {len(flat)} questions unchanged.")
    if single:
        print(f"  {single} questions probed only once — no comparison possible.")
    if not moved and flat:
        print("\n  Nothing moved. Say so plainly rather than reaching for a story.")


def cmd_history(a):
    runs = sorted((proj_dir(a.domain) / "runs").glob("*/manifest.json"))
    if not runs:
        print("No runs recorded.")
        return
    print(f"{'RUN':<18} {'AT':<22} FILES")
    print("-" * 78)
    for m in runs:
        d = read(m, {})
        print(f"{d.get('run_id',''):<18} {d.get('at',''):<22} "
              f"{', '.join((d.get('files') or {}).keys())}")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("add"); s.add_argument("domain")
    s.add_argument("--vertical", help="group label for calibration (e.g. saas, local, ecom)")
    s.set_defaults(fn=cmd_add)
    s = sub.add_parser("list"); s.set_defaults(fn=cmd_list)

    s = sub.add_parser("record"); s.add_argument("domain")
    for k in ("crawl", "expand", "probe", "briefs"):
        s.add_argument(f"--{k}")
    s.set_defaults(fn=cmd_record)

    s = sub.add_parser("briefs"); s.add_argument("domain")
    s.add_argument("--status", choices=STATUSES); s.set_defaults(fn=cmd_briefs)

    s = sub.add_parser("set-status"); s.add_argument("domain")
    s.add_argument("brief_id"); s.add_argument("status", choices=STATUSES)
    s.add_argument("--note"); s.set_defaults(fn=cmd_set_status)

    s = sub.add_parser("movement"); s.add_argument("domain"); s.set_defaults(fn=cmd_movement)
    s = sub.add_parser("history"); s.add_argument("domain"); s.set_defaults(fn=cmd_history)

    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
