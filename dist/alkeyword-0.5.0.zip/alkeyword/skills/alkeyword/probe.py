#!/usr/bin/env python3
"""
Alkeyword prototype — Stage 2: PROBE + Stage 3: DIFF.

Consumes the JSON emitted by crawl.py. Generates a question set from the claim
graph, asks real engines, and diffs what they say against what the site says.

Design rules from the spec, enforced here:
  §2.3  N runs per (question, engine); report RATES, never binaries.
  §2.2  Per-engine reporting. Never blend engines into one score.
  §2.5  Disk cache keyed (question, engine, week).
  §3    Gaps are typed, with a detection rule each.

Cost: every probe is a real paid API call. Nothing is spent without --run,
and the estimate is printed first. Default engine is the cheapest that cites.

Usage:
    python3 probe.py crawl.json                      # dry run: show the plan + cost
    python3 probe.py crawl.json --run                # actually spend
    python3 probe.py crawl.json --run --runs 3 --max-questions 8
"""

import argparse
import hashlib
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict

API = "https://openrouter.ai/api/v1/chat/completions"
CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".probe_cache")

# Engines are reported separately, never averaged (spec §2.2).
ENGINES = {
    "perplexity": {"model": "perplexity/sonar", "est_cost": 0.005},
    "perplexity-pro": {"model": "perplexity/sonar-pro", "est_cost": 0.020},
}

# Domains that are infrastructure, not competitors.
GENERIC = {
    "wikipedia.org", "reddit.com", "github.com", "youtube.com", "linkedin.com",
    "medium.com", "x.com", "twitter.com", "facebook.com", "arxiv.org",
    "stackoverflow.com", "news.ycombinator.com", "google.com",
}


# ---------------------------------------------------------------- questions


def registrable(host):
    host = host.lower().lstrip("www.")
    parts = host.split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else host


def infer_category(crawl):
    """Short category label from meta description / homepage title."""
    home = crawl["pages"][0] if crawl["pages"] else {}
    text = (home.get("meta_description") or home.get("title") or "")
    m = re.search(
        r"\b(protocol|framework|platform|engine|library|standard|toolkit|API|SDK|"
        r"benchmark|kernel|runtime|research program|spec(?:ification)?)\b", text, re.I)
    return m.group(1).lower() if m else "tool"


def build_questions(crawl, max_q, expand=None):
    """Question set for probing.

    CRITICAL: pass `expand` (expand.py's --json). Without it this generates its own
    questions from the claim graph, which do NOT overlap the autocomplete queries the
    briefs target — so baselines and briefs end up in disjoint key spaces and
    calibration can never link a published brief to a measured movement. Verified:
    intersection was exactly zero. Measure what you're trying to move.
    """
    entity = crawl["entity"]
    domain = crawl["domain"]
    cat = infer_category(crawl)
    claims = crawl["claims"]
    qs = []

    def add(kind, text, expect=None, claim_id=None):
        qs.append({"id": f"q{len(qs):03d}", "kind": kind, "text": text,
                   "expect": expect, "claim_id": claim_id})

    # 1. brand questions — cheapest to win, most embarrassing to lose
    add("brand", f"What is {entity} ({domain})?")
    add("brand", f"Who is {entity} ({domain}) for, and what problem does it solve?")
    add("brand", f"Is {entity} ({domain}) a real, actively maintained project?")

    # 2. targeted — the exact queries the briefs are written against, verbatim.
    #    These are what make calibration possible; do not rephrase the string.
    if expand:
        ranked = sorted(
            (q for q in expand.get("queries", [])
             if (q.get("material") or {}).get("verdict") in ("ready", "thin")),
            key=lambda q: -((q.get("material") or {}).get("strong", 0)))
        for q in ranked[: max(1, max_q // 2)]:
            add("targeted", q["query"])

    # 3. category questions — where you're absent and someone else is cited
    add("category", f"What is the best open {cat} for machine cognition and agent governance?")
    add("category", f"What {cat}s exist for measuring or governing AI agent decision-making?")

    # 3. claim-derived — invert the site's own high-value claims into questions.
    #    `expect` is what the site says, so the diff can detect a wrong answer.
    seen_ctx = set()
    for c in claims:
        if c["type"] != "quantity" or c["confidence"] < 0.7:
            continue
        span = c["text_span"]
        # only claims with enough surrounding context to form a question
        words = [w for w in re.findall(r"[a-zA-Z][a-zA-Z\-]{3,}", span)][:6]
        if len(words) < 3:
            continue
        ctx = " ".join(w.lower() for w in words[:4])
        if ctx in seen_ctx:
            continue
        seen_ctx.add(ctx)
        topic = " ".join(words[:5])
        add("claim", f"Regarding {entity}: {topic} — what are the exact numbers?",
            expect=c["object"], claim_id=c["id"])
        if len(qs) >= max_q:
            break

    return qs[:max_q]


# ---------------------------------------------------------------- probing


def cache_key(question, model, run_idx):
    week = time.strftime("%Y-W%W")
    raw = f"{question}|{model}|{run_idx}|{week}"
    return hashlib.sha256(raw.encode()).hexdigest()[:24]


def probe_once(question, model, api_key, run_idx, use_cache=True):
    os.makedirs(CACHE_DIR, exist_ok=True)
    path = os.path.join(CACHE_DIR, cache_key(question, model, run_idx) + ".json")
    if use_cache and os.path.exists(path):
        with open(path) as f:
            r = json.load(f)
            r["cached"] = True
            return r

    body = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": question}],
        "max_tokens": 500,
        # nudge variance so N runs measure real non-determinism, not a frozen sample
        "temperature": 0.7,
    }).encode()
    req = urllib.request.Request(
        API, data=body,
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            d = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}: {e.read().decode()[:200]}", "cached": False}
    except Exception as e:
        return {"error": str(e), "cached": False}

    msg = d.get("choices", [{}])[0].get("message", {})
    cites = []
    for a in msg.get("annotations") or []:
        u = (a.get("url_citation") or {}).get("url")
        if u:
            cites.append(u)
    out = {
        "answer": msg.get("content", ""),
        "cited_urls": cites,
        "cost": (d.get("usage") or {}).get("cost", 0.0),
        "cached": False,
    }
    with open(path, "w") as f:
        json.dump(out, f)
    return out


def analyse(result, entity, domain):
    """Extract the diffable signal from one answer."""
    ans = result.get("answer", "")
    low = ans.lower()
    own = registrable(domain)

    # brand mention: full name, or the distinctive leading token
    tokens = [t for t in re.findall(r"[A-Za-z][\w&\[\]]{2,}", entity) if len(t) > 3]
    mentioned = entity.lower() in low or any(t.lower() in low for t in tokens[:2])

    cited_domains = []
    for u in result.get("cited_urls", []):
        try:
            cited_domains.append(registrable(urllib.parse.urlsplit(u).netloc))
        except Exception:
            pass

    return {
        "brand_mentioned": mentioned,
        "own_domain_cited": own in cited_domains,
        "cited_domains": cited_domains,
        "competitors": [d for d in dict.fromkeys(cited_domains)
                        if d != own and d not in GENERIC],
        "numbers": QUANT.findall(ans),
        "answer": ans,
    }


QUANT = re.compile(r"\b\d[\d,]*(?:\.\d+)?\s?(?:%|laws?|tests?|trials?|rungs?|pages?|x)?\b")


# ---------------------------------------------------------------- diff


def diff(questions, results, crawl):
    """Gap detection (spec §3). Every gap reports a RATE, never a binary."""
    entity, domain = crawl["entity"], crawl["domain"]
    own = registrable(domain)
    gaps = []

    for q in questions:
        runs = results.get(q["id"], [])
        ok = [r for r in runs if "error" not in r]
        if not ok:
            continue
        n = len(ok)
        mention_n = sum(1 for r in ok if r["brand_mentioned"])
        cited_n = sum(1 for r in ok if r["own_domain_cited"])
        comps = defaultdict(int)
        for r in ok:
            for c in r["competitors"]:
                comps[c] += 1
        top = sorted(comps.items(), key=lambda kv: -kv[1])[:5]

        base = {"question_id": q["id"], "question": q["text"], "kind": q["kind"],
                "runs": n, "mention_rate": f"{mention_n}/{n}",
                "citation_rate": f"{cited_n}/{n}",
                "competitors_cited": [f"{d} ({c}/{n})" for d, c in top]}

        # G3 — ceded question: they answer it, cite someone else, not you
        if cited_n == 0 and top:
            gaps.append({**base, "gap": "G3", "label": "Ceded question",
                         "detail": f"Own domain cited in 0/{n} runs; "
                                   f"{len(top)} other domains cited instead."})

        # G1 — dark fact: site states it, engine can't surface it
        elif q["kind"] == "claim" and cited_n < n:
            gaps.append({**base, "gap": "G1", "label": "Dark fact",
                         "detail": f"Site states this, own domain cited in only {cited_n}/{n} runs."})

        # G2 — wrong fact: site says X, engine says a different number
        if q["kind"] == "claim" and q.get("expect"):
            exp_nums = set(re.findall(r"\d[\d,]*", q["expect"]))
            for r in ok:
                got = set(x.strip() for x in re.findall(r"\b\d[\d,]*\b", r["answer"]))
                if exp_nums and not (exp_nums & got) and got:
                    gaps.append({**base, "gap": "G2", "label": "Possible wrong fact",
                                 "detail": f"Site states {sorted(exp_nums)}; "
                                           f"answer contains {sorted(got)[:6]} and not the site's value."})
                    break

        # low brand recognition on a brand question is its own signal
        if q["kind"] == "brand" and mention_n < n:
            gaps.append({**base, "gap": "G8", "label": "Weak entity resolution",
                         "detail": f"Brand named in only {mention_n}/{n} runs on a direct brand question."})

    return gaps


# ---------------------------------------------------------------- report


def report(crawl, questions, results, gaps, spent):
    W = 76
    print("\n" + "=" * W)
    print(f"  ALKEYWORD — STAGE 2 PROBE + STAGE 3 DIFF   ·   {crawl['domain']}")
    print("=" * W)
    print(f"  Entity    : {crawl['entity']}")
    print(f"  Questions : {len(questions)}")
    print(f"  Spent     : ${spent:.4f}")

    print("\n  PER-QUESTION VISIBILITY   (rates, not binaries — spec §2.3)")
    print("  " + "-" * (W - 4))
    for q in questions:
        runs = [r for r in results.get(q["id"], []) if "error" not in r]
        if not runs:
            print(f"  [{q['id']}] {q['kind']:<9} ERROR")
            continue
        n = len(runs)
        m = sum(1 for r in runs if r["brand_mentioned"])
        c = sum(1 for r in runs if r["own_domain_cited"])
        flag = "✓" if c == n else ("~" if c else "✗")
        print(f"  {flag} [{q['id']}] {q['kind']:<9} named {m}/{n}  cited {c}/{n}")
        print(f"       {q['text'][:68]}")

    if gaps:
        print("\n  GAPS DETECTED")
        print("  " + "-" * (W - 4))
        for g in sorted(gaps, key=lambda g: g["gap"]):
            print(f"  [{g['gap']}] {g['label']}  ({g['question_id']})")
            print(f"       {g['detail']}")
            if g["competitors_cited"]:
                print(f"       cited instead: {', '.join(g['competitors_cited'][:4])}")

    # competitor roll-up across all questions
    allc = defaultdict(int)
    for q in questions:
        for r in results.get(q["id"], []):
            if "error" in r:
                continue
            for d in set(r["competitors"]):
                allc[d] += 1
    if allc:
        print("\n  DOMAINS CITED INSTEAD OF YOU (across all runs)")
        print("  " + "-" * (W - 4))
        for d, n in sorted(allc.items(), key=lambda kv: -kv[1])[:12]:
            print(f"    {n:>3}×  {d}")
    print("=" * W + "\n")


# ---------------------------------------------------------------- main


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("crawl_json")
    ap.add_argument("--engine", default="perplexity", choices=list(ENGINES))
    ap.add_argument("--runs", type=int, default=3, help="N per question (spec §2.3)")
    ap.add_argument("--max-questions", type=int, default=10)
    ap.add_argument("--expand", help="expand.py --json — REQUIRED for calibration; without it probe questions and brief questions land in disjoint key spaces")
    ap.add_argument("--run", action="store_true", help="actually spend money")
    ap.add_argument("--no-cache", action="store_true")
    ap.add_argument("--json", help="write probe+gap output here")
    a = ap.parse_args()

    with open(a.crawl_json) as f:
        crawl = json.load(f)

    expand = None
    if a.expand:
        with open(a.expand) as f:
            expand = json.load(f)
    else:
        print('warning: no --expand given. Probe questions will not match the '
              'queries briefs target, so calibration cannot link them.',
              file=sys.stderr)
    questions = build_questions(crawl, a.max_questions, expand)
    eng = ENGINES[a.engine]
    n_calls = len(questions) * a.runs
    est = n_calls * eng["est_cost"]

    print(f"\nPLAN  ·  {crawl['domain']}  ·  entity: {crawl['entity']}")
    print(f"  engine     : {a.engine} ({eng['model']})")
    print(f"  questions  : {len(questions)}  ×  {a.runs} runs  =  {n_calls} calls")
    print(f"  est. cost  : ${est:.3f}  (~${eng['est_cost']:.3f}/call)\n")
    for q in questions:
        exp = f"   [site says: {q['expect']}]" if q.get("expect") else ""
        print(f"  [{q['id']}] {q['kind']:<9} {q['text'][:64]}{exp}")

    if not a.run:
        print("\n  DRY RUN — nothing spent. Re-run with --run to execute.\n")
        return

    key = os.environ.get("OPENROUTER_API_KEY")
    if not key:
        print("\nERROR: set OPENROUTER_API_KEY in the environment.\n", file=sys.stderr)
        sys.exit(1)

    print(f"\nprobing ({n_calls} calls)...", file=sys.stderr)
    results, spent = defaultdict(list), 0.0
    for q in questions:
        for i in range(a.runs):
            raw = probe_once(q["text"], eng["model"], key, i, use_cache=not a.no_cache)
            if "error" in raw:
                print(f"  {q['id']} run{i}: {raw['error'][:90]}", file=sys.stderr)
                results[q["id"]].append(raw)
                continue
            spent += raw.get("cost", 0.0) if not raw.get("cached") else 0.0
            results[q["id"]].append(analyse(raw, crawl["entity"], crawl["domain"]))
            tag = "cache" if raw.get("cached") else f"${raw.get('cost', 0):.4f}"
            print(f"  {q['id']} run{i}  {tag}", file=sys.stderr)
            if not raw.get("cached"):
                time.sleep(0.5)

    gaps = diff(questions, results, crawl)
    report(crawl, questions, results, gaps, spent)

    if a.json:
        with open(a.json, "w") as f:
            json.dump({"domain": crawl["domain"], "entity": crawl["entity"],
                       "questions": questions, "gaps": gaps,
                       "results": {k: v for k, v in results.items()},
                       "spent": spent}, f, indent=2)
        print(f"wrote {a.json}", file=sys.stderr)


if __name__ == "__main__":
    main()
