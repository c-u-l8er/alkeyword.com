#!/usr/bin/env python3
"""
Alkeyword — dashboard. Renders the local store as one self-contained HTML file.

No server, no framework, no network. Reads ~/.alkeyword and writes a file you
open in a browser. Works offline, and there is nothing to host or secure because
the research never leaves your machine.

    dashboard.py [--out alkeyword.html] [--open]
"""

import argparse
import html
import json
import os
import pathlib
import subprocess
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from store import ROOT, read, registry, proj_dir  # noqa: E402

STATUS_ORDER = ["new", "writing", "written", "published", "dropped"]
STATUS_COLOR = {"new": "#d9a441", "writing": "#4a9e8f", "written": "#6fa8dc",
                "published": "#7fbf5f", "dropped": "#6c7280"}

CSS = """
*{box-sizing:border-box}
body{margin:0;background:#0d0f14;color:#e8e6e1;font:16px/1.6 ui-sans-serif,system-ui,sans-serif}
.wrap{max-width:1000px;margin:0 auto;padding:32px 24px 80px}
h1{font-size:1.7rem;margin:0 0 4px;letter-spacing:-.02em}
h2{font-size:1.15rem;margin:36px 0 12px;letter-spacing:-.01em}
h3{font-size:.95rem;margin:0 0 8px}
.sub{color:#d9a441;font-family:ui-monospace,monospace;font-size:.78rem;
     letter-spacing:.16em;text-transform:uppercase;margin-bottom:22px}
.muted{color:#9aa0ab}.faint{color:#6c7280;font-size:.85rem}
table{width:100%;border-collapse:collapse;font-size:.92rem;margin:10px 0 4px}
th,td{text-align:left;padding:9px 10px;border-bottom:1px solid #232833;vertical-align:top}
th{font-family:ui-monospace,monospace;font-size:.68rem;letter-spacing:.1em;
   text-transform:uppercase;color:#6c7280;font-weight:500}
td{color:#9aa0ab}td.k{color:#e8e6e1}
.pill{display:inline-block;padding:2px 9px;border-radius:99px;font-size:.72rem;
      font-family:ui-monospace,monospace;color:#0d0f14;font-weight:600}
.cols{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:12px 0}
.col{border:1px solid #232833;border-radius:9px;background:#12151c;padding:14px;min-height:80px}
.col h3{font-family:ui-monospace,monospace;font-size:.7rem;letter-spacing:.12em;
        text-transform:uppercase}
.card{border:1px solid #232833;border-radius:7px;padding:9px 10px;margin-bottom:8px;
      background:#0d0f14;font-size:.85rem}
.card .q{color:#e8e6e1;display:block;margin-bottom:3px}
.up{color:#7fbf5f}.down{color:#c15f3c}.flat{color:#6c7280}
.proj{border:1px solid #232833;border-radius:10px;background:#12151c;padding:20px;margin-bottom:22px}
.empty{border:1px dashed #232833;border-radius:9px;padding:26px;text-align:center;color:#6c7280}
code{font-family:ui-monospace,monospace;font-size:.85em;color:#d9a441}
.scroll{overflow-x:auto}
@media(prefers-color-scheme:light){
 body{background:#fbfaf7;color:#1a1c22}.proj,.col{background:#f3f1ec;border-color:#e0dcd2}
 .card{background:#fff;border-color:#e0dcd2}.card .q{color:#1a1c22}
 th,td{border-color:#e0dcd2}.muted,td{color:#4e5561}
}
"""


def esc(s):
    return html.escape(str(s if s is not None else ""))


def movement_rows(domain):
    base = read(proj_dir(domain) / "baselines.json", {"questions": {}})
    rows = []
    for q, entry in base.get("questions", {}).items():
        h = entry["history"]
        if len(h) < 2:
            rows.append((q, None, f"{h[-1]['cited']}/{h[-1]['n']}", None))
            continue
        p, c = h[-2], h[-1]
        rows.append((q, f"{p['cited']}/{p['n']}", f"{c['cited']}/{c['n']}",
                     c["cited"] / c["n"] - p["cited"] / p["n"]))
    rows.sort(key=lambda r: (r[3] is None, -(r[3] or 0)))
    return rows


def render_project(dom, meta):
    briefs = read(proj_dir(dom) / "briefs.json", {"briefs": {}}).get("briefs", {})
    runs = sorted((proj_dir(dom) / "runs").glob("*/manifest.json"))
    L = [f'<div class="proj"><h2>{esc(dom)}</h2>',
         f'<p class="faint">{esc(meta.get("entity") or "entity not resolved")} · '
         f'{meta.get("runs", 0)} runs · last {esc(meta.get("last_run") or "never")}</p>']

    # briefs by status
    if briefs:
        L.append('<div class="cols">')
        for st in STATUS_ORDER:
            items = [b for b in briefs.values() if b["status"] == st]
            L.append(f'<div class="col"><h3 style="color:{STATUS_COLOR[st]}">'
                     f'{st} ({len(items)})</h3>')
            for b in sorted(items, key=lambda b: -(b.get("score") or 0)):
                q = b["questions"][0] if b["questions"] else b["key"]
                flag = "" if b["satisfied"] else ' <span class="faint">needs material</span>'
                L.append(f'<div class="card"><span class="q">{esc(q[:64])}</span>'
                         f'<span class="faint">{esc(b["form"])}{flag}</span>')
                if b.get("note"):
                    L.append(f'<br><span class="faint">note: {esc(b["note"])}</span>')
                L.append('</div>')
            L.append('</div>')
        L.append('</div>')
    else:
        L.append('<div class="empty">No briefs recorded yet.<br>'
                 '<code>store.py record &lt;domain&gt; --briefs briefs.json</code></div>')

    # movement
    rows = movement_rows(dom)
    if rows:
        L.append('<h3>Citation movement</h3><div class="scroll"><table>'
                 '<tr><th>Question</th><th>Previous</th><th>Latest</th><th>Change</th></tr>')
        for q, prev, cur, delta in rows[:14]:
            if delta is None:
                d = '<span class="flat">first probe</span>'
            elif delta > 0:
                d = f'<span class="up">▲ +{delta:.2f}</span>'
            elif delta < 0:
                d = f'<span class="down">▼ {delta:.2f}</span>'
            else:
                d = '<span class="flat">—</span>'
            L.append(f'<tr><td class="k">{esc(q[:70])}</td><td>{esc(prev or "—")}</td>'
                     f'<td>{esc(cur)}</td><td>{d}</td></tr>')
        L.append('</table></div>')

    if runs:
        L.append('<h3>Runs</h3><div class="scroll"><table>'
                 '<tr><th>Run</th><th>When</th><th>Recorded</th></tr>')
        for m in reversed(runs[-8:]):
            d = read(m, {})
            L.append(f'<tr><td class="k">{esc(d.get("run_id"))}</td>'
                     f'<td>{esc(d.get("at"))}</td>'
                     f'<td>{esc(", ".join((d.get("files") or {}).keys()))}</td></tr>')
        L.append('</table></div>')

    L.append('</div>')
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="alkeyword.html")
    ap.add_argument("--open", action="store_true", help="open in the default browser")
    a = ap.parse_args()

    reg = registry()
    projects = reg.get("projects", {})

    body = [f'<div class="sub">al · keyword</div><h1>Local dashboard</h1>',
            f'<p class="muted">{len(projects)} project'
            f'{"" if len(projects) == 1 else "s"} · reading <code>{esc(ROOT)}</code></p>']

    if not projects:
        body.append('<div class="empty">Nothing tracked yet.<br>'
                    '<code>store.py add example.com</code></div>')
    else:
        for dom, meta in sorted(projects.items()):
            body.append(render_project(dom, meta))

    doc = (f'<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
           f'<meta name="viewport" content="width=device-width,initial-scale=1">'
           f'<title>Alkeyword — local dashboard</title><style>{CSS}</style></head>'
           f'<body><div class="wrap">{"".join(body)}'
           f'<p class="faint" style="margin-top:40px">Generated from your local store. '
           f'Nothing here left your machine.</p></div></body></html>')

    out = pathlib.Path(a.out).resolve()
    out.write_text(doc)
    print(f"wrote {out}")

    if a.open:
        opener = "open" if sys.platform == "darwin" else "xdg-open"
        try:
            subprocess.run([opener, str(out)], check=False)
        except FileNotFoundError:
            print(f"open it manually: file://{out}", file=sys.stderr)


if __name__ == "__main__":
    main()
