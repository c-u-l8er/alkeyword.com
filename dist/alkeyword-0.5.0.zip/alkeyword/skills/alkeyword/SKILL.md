---
name: alkeyword
description: Analyze a website's AI-search visibility from a bare domain name. Crawls the site, builds a claim graph of everything it already states, probes what AI engines say about it, and generates content that closes the measured gaps — grounded so every factual sentence traces back to the site's own words. Use when the user gives a domain and asks about GEO, AI search visibility, why ChatGPT/Perplexity don't cite them, or wants content generated for a site.
---

# Alkeyword

**Transmute, never fabricate.** The site's own content is the raw material. Nothing is invented.

Runs on the Claude harness — no API keys, no per-token billing. The crawl and diff are
deterministic Python (free); only extraction, phrasing, and generation use the model.

---

## Stage 1 — Crawl (deterministic, free)

Always start here. It costs nothing and produces the claim graph everything else needs.

```bash
python3 skills/alkeyword/crawl.py <domain> --max-pages 40 --json /tmp/alk-<domain>.json
```

Stdlib only — no install step. Report the free findings immediately, before anything else:

- `robots.txt` blocking `GPTBot` / `ClaudeBot` / `PerplexityBot` — **if this fires, stop and
  report it.** The site is invisible to AI search by its own configuration; nothing downstream
  matters until it's fixed.
- Self-contradictions, duplicate URLs, orphaned high-value pages, unsourced numbers, missing schema.

Read the `--json` output for the claim graph. Claim types, ranked by citation value:
`quantity` (strongest measured lever) · `quote` (second) · `definition` · `comparison` ·
`question` · `credential` · `process` · `attribute`.

## Stage 1b — Re-extract claims properly

The Python extractor is heuristic and has one known root failure: **no subject resolution.**
It over-fires on `definition`, dumps ~73% of claims into `attribute`, and cannot build
claim→claim edges or trust its own contradiction detection.

Re-read the crawled pages and redo the extraction yourself. Resolve subjects. For each claim
record: type, subject, predicate, object, verbatim `text_span`, and `source_url`. Only then are
`contradicts` edges and material-sufficiency scoring trustworthy.

## Stage 2a — Expand (free keyword + question research)

```bash
python3 skills/alkeyword/expand.py /tmp/alk-<domain>.json --seeds "term1,term2,term3" --json /tmp/alk-exp.json
```

Mines Google + DuckDuckGo autocomplete — real queries people typed, free, no API key. These beat
paid volume data for this purpose: in a generative engine the unit of demand is a question, not a
keyword with a number beside it.

**Always pass `--seeds` yourself, from the subjects you resolved in stage 1b.** Auto-seeding
inherits the heuristic extractor's bogus `definition` claims and the results are worthless.
Measured on a live site, identical code and claim graph, only the seeds differing:

| | auto-seeded | seeds resolved properly |
|---|---|---|
| ready | 0 | 2 |
| thin | 3 | 66 |
| none | 312 | 9 |

Good seeds: the category vocabulary, the jobs-to-be-done, competitors the site names itself.
Not sentence fragments, not the brand name alone.

Two findings this stage produces on its own:

- **"Autocomplete has no data for this term"** — every suggestion drifted off-seed. Nobody is
  searching it. That's a *positioning* finding, not a content one: demand has to be captured on
  category language because the brand name has no volume.
- **Demand you don't serve** — real queries with zero material on the site. A strategy question
  for the user to answer, not a page to write.

## Stage 2b — Probe

Generate the question set from the claim graph — three generators:

1. **Brand** — `What is <entity>?` · `Is <entity> legit?` · `<entity> vs <competitor>` ·
   `How much does <entity> cost?`
2. **Category** — `best <category> for <ICP>` · `what tools exist for <job-to-be-done>`
3. **Claim-derived** — invert each high-value claim into the question it answers.
   *"99.9% uptime"* → *"what uptime does \<entity\> guarantee?"* Carry the site's stated value
   as `expect` so the diff can detect a wrong answer.

Phrase them the way a person actually types into an engine. Skip identifiers that aren't
really quantities (arXiv IDs, version numbers, years-in-a-citation).

Then probe with **WebSearch**, once per question. That measures the Claude/web-search surface —
one real engine, free on the subscription. Record per question: is the entity named, is its
domain cited, which domains are cited instead.

**Say plainly that this is one engine.** Cross-engine citation overlap is only ~11%, so a Claude
result implies nothing about ChatGPT, Perplexity, or AI Overviews. Never present it as
"your AI visibility" — present it as "your visibility in this one surface."

If the user wants multi-engine coverage, that needs their own API keys and real per-probe cost —
tell them the tradeoff, don't quietly skip it or quietly spend.

## Stage 3 — Diff

| ID | Gap | Detection | Action |
|---|---|---|---|
| **G1** | Dark fact | Site states `C`; engine doesn't surface it | Mint a page where `C` is the headline answer |
| **G2** | Wrong fact | Engine asserts `X`; site claims `¬X` | Canonical correction page + schema. *Highest urgency* |
| **G3** | Ceded question | Competitor cited; site has material but no page | **Primary generation trigger** |
| **G4** | Unsupported claim | Claim with no data or source | Strengthen with the site's own numbers |
| **G5** | Missing form | Material exists for a high-citation page type never built | Mint it |
| **G6** | Self-contradiction | Two site claims conflict | Resolve *before* generating |
| **G7** | Orphan | Valuable claim, ≤1 inbound link | Internal linking — no generation needed |
| **G8** | Thin entity | No schema, no author, no about page | Entity page + `Organization` schema |
| **G9** | Blocked | `robots.txt` blocks AI crawlers | Unblock, or accept invisibility |
| **G10** | Duplicate URLs | Same content at >1 URL, no canonical | Canonicalize |

Rank by `reach × winnability × material_sufficiency ÷ effort`.

Before claiming a G2, check the site's `modified_at` — models lag. **Label model staleness
differently from a genuine error.** A false "the AI is wrong about you" destroys trust in the
whole report.

## Stage 4 — Brief (the deliverable)

**The product is the research. The human writes.** Over 90% of pages cited in AI search already
contain AI-generated text, so generating more of it is not a differentiator — the research behind
it is. Human-written content earns ~5.44× the traffic and holds it.

```bash
python3 skills/alkeyword/brief.py /tmp/alk-<domain>.json /tmp/alk-exp.json \
    [--probe /tmp/alk-probe.json] --out briefs.md
```

Renders ranked briefs as markdown. It clusters queries **by the claims they share** — two
queries answered by the same claims are one page — picks the highest-*value* form the material
actually supports, collapses claims duplicated across duplicate URLs (flagging them), and
attaches the raw material verbatim.

Read the output and improve it. The renderer is mechanical; you have judgment it doesn't:
tighten the outline, drop claims that don't really belong, name the missing facts more
specifically than "2 more quantity claims."

Each brief must be specific enough that writing from it is **assembly, not research** — that is
what separates a brief from a dashboard, and dashboards are what makes people churn out of this
category.

Every brief carries:

- **The questions**, verbatim as people type them (from stage 2a + the probe)
- **The keyword cluster** for the same topic
- **Current state** — who is cited today, at what rate, on which engine
- **The raw material** — the actual claims from their own site, with `text_span` and `source_url`.
  *Non-negotiable. A brief without this is a keyword list with extra steps.*
- **What's missing** — named specifically
- **Recommended form** and a section outline, each heading mapped to claim IDs

Use the material verdict from stage 2a to sort: `ready` briefs first, then `thin` with a shopping
list, then `none` flagged as strategy questions rather than assignments.

### The refusal rule becomes a shopping list

Same threshold, more useful shape:

> **Not yet.** A comparison page needs ≥8 shared attributes and ≥2 quantities. You have 3 claims
> about X, all on `/features`. Gather: a price figure, one third-party citation, and 4 more
> attribute rows — then this is a ready brief.

## Stage 4b — Generate (only if asked)

Never the default, never bulk. Offer it per-brief: *"want a draft of this one?"* The brief already
contains everything a draft needs. If the user doesn't ask, don't.

Only for gaps that pass material sufficiency:

| Form | Requires |
|---|---|
| Comparison | ≥2 entities, ≥6 shared attributes, ≥2 quantities |
| Glossary | ≥1 definition + ≥2 elaborating claims |
| FAQ | ≥5 question claims |
| Statistics page | ≥5 quantities with units |
| How it works | ≥1 process with ≥3 ordered steps |
| Entity / about | entity + ≥3 credentials |

**The refusal rule.** Below threshold, report the gap and refuse to generate, saying exactly
what's missing: *"You have 3 claims about X. A comparison page needs 8, including 2 quantities."*

This is the load-bearing rule of the whole tool. A 3-page brochure site gets an honest
"there's nothing here to transmute yet." Generating anyway is what Google's March 2026 update
penalized — sites publishing bulk AI pages without editorial oversight took 50–80% traffic drops.
Do not relax it because the user is disappointed.

**Provenance is mandatory.** Every factual sentence traces to ≥1 claim ID, and the claim's
`text_span` must actually support it. Sentences that fail get flagged for human fill-in, never
shipped silently. Emit the provenance map alongside the content.

Cap output at ~6 pieces. Emit markdown + HTML with JSON-LD (`FAQPage`, `DefinedTerm`, `HowTo`,
`Organization`). Publishing is the user's job — detect the CMS from the crawl and hand off.

## Persist every run — otherwise stage 5 is impossible

```bash
python3 skills/alkeyword/store.py record <domain> \
    --crawl crawl.json --expand exp.json --probe probe.json --briefs briefs.json
```

State lives in `~/.alkeyword` (override with `ALKEYWORD_HOME`). Local files only — no server,
no account, nothing leaves the machine. **Record at the end of every session.** Without it there
is no baseline, so nothing below can run.

Brief status survives regeneration — briefs are keyed on their claim set, not position, so
marking one `written` sticks even after the whole set is recomputed.

```bash
store.py list                                   # all tracked projects
store.py briefs <domain>                        # status board
store.py set-status <domain> <key> written --note "..."
store.py movement <domain>                      # stage 5 deltas
store.py history <domain>
python3 skills/alkeyword/dashboard.py --open    # one self-contained HTML file
```

Offer the dashboard when the user has more than a couple of briefs or more than one run — a
kanban of brief statuses and a citation-movement table read far better than terminal output.

## Config

```bash
python3 skills/alkeyword/config.py show      # effective settings
python3 skills/alkeyword/config.py set crawl.max_pages 80
```

Most values are the user's to tune. **A few are clamped and cannot be raised**, because a
safety constraint that can be silently deleted is not one:

| Setting | Guard | Why |
|---|---|---|
| `generate.max_pieces_per_cycle` | ≤ 12 | Volume is the penalty pattern |
| `generate.require_human_review` | forced `true` | Unreviewed publishing is where the risk lives |
| `brief.cluster_min_strong` | ≥ 2 | Below this a brief carries no raw material |
| `expand.ready_strong_claims` | ≥ 3 | Marking "ready" on less sends people to write pages they can't support |
| `probe.runs` | ≥ 2 | One sample can't produce a rate |
| any form's requirements | ≥ 2 claims total | A form with no requirement disables the refusal rule |

If a user asks to exceed one of these, don't work around it. Explain the reason and offer what
they're actually after — usually more briefs (`brief.max_briefs` is unguarded) rather than more
generated pages.

## Stage 5 — Re-probe and calibrate

```bash
python3 skills/alkeyword/calibrate.py
```

Links each **published** brief to the questions it targeted, compares probe rates before and
after publication, and aggregates by form and vertical. This is what turns the built-in form
values from informed guesses into measured priors for *these* sites.

Three preconditions, all required: a brief marked `published`, a probe recorded **before** that
date, and one **after**. Missing any, it reports nothing rather than inventing a trend.

⚠️ **Always pass `--expand` to probe.py.** Without it the probe generates its own questions,
which do not overlap the autocomplete queries briefs target — baselines and briefs land in
disjoint key spaces and calibration silently measures nothing. Verified: the intersection was
exactly zero.

**Respect the verdict column.** Below the sample threshold it prints `NOT A FINDING`, and that
is not hedging — a form showing +0.667 on n=1 is noise. Do not re-rank anything on it, and do
not summarise it to the user as "X works best."

Offer a re-check in ~30 days on the exact questions targeted. Report movement, and say plainly
if nothing moved.

---

## Reporting rules

- **Rates, not binaries.** Engines are non-deterministic. Where you sample more than once, say
  "cited in 2 of 3 runs." Never state a single sample as settled fact.
- **Never blend engines into one score.** Report per engine.
- **Don't fabricate coverage.** If only one surface was probed, the headline says so.
