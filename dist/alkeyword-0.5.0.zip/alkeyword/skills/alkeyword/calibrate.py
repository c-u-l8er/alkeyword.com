#!/usr/bin/env python3
"""
Alkeyword — calibration. Which forms actually moved citations, measured.

The gap library's form values (comparison=6, glossary=1, …) started as informed
guesses from published research. This turns them into measured priors from YOUR
outcomes: link every published brief to the questions it targeted, compare probe
rates before and after publication, and aggregate by form and vertical.

That loop is the compounding asset — nobody else in this category closes it,
because measuring it requires persisting baselines across months.

DISCIPLINE THIS FILE ENFORCES: it refuses to call a small sample a finding.
Below `calibration.min_samples_to_report` it prints the numbers and labels them
NOT A FINDING. A tool that dresses n=1 up as a measured prior is worse than one
that measures nothing, because you would act on it.

    calibrate.py                 # across all projects
    calibrate.py --domain d.com  # one project
    calibrate.py --json out.json
"""

import argparse
import json
import pathlib
import sys
from collections import defaultdict
from datetime import datetime

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from store import read, registry, proj_dir  # noqa: E402
import config as cfg_mod  # noqa: E402


def parse_ts(s):
    try:
        return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ")
    except (TypeError, ValueError):
        return None


def rate(entry):
    return entry["cited"] / entry["n"] if entry.get("n") else 0.0


def measure_brief(brief, baselines):
    """Compare citation rate before vs after this brief was published.

    Returns per-question deltas, or None when the brief was never published or
    has no probe on both sides of the publication date.
    """
    if brief.get("status") != "published":
        return None
    published_at = parse_ts(brief.get("status_changed"))
    if not published_at:
        return None

    up = down = flat = 0
    deltas, unmeasurable = [], 0

    for q in brief.get("questions", []):
        hist = (baselines.get("questions", {}).get(q) or {}).get("history", [])
        before = [h for h in hist if (parse_ts(h.get("at")) or published_at) < published_at]
        after = [h for h in hist if (parse_ts(h.get("at")) or published_at) >= published_at]
        if not before or not after:
            unmeasurable += 1
            continue
        d = rate(after[-1]) - rate(before[-1])
        deltas.append(d)
        if d > 1e-9:
            up += 1
        elif d < -1e-9:
            down += 1
        else:
            flat += 1

    if not deltas:
        return {"measured": 0, "unmeasurable": unmeasurable}
    return {"measured": len(deltas), "unmeasurable": unmeasurable,
            "up": up, "flat": flat, "down": down,
            "avg_delta": sum(deltas) / len(deltas)}


def collect(domains):
    by_form, by_vertical, rows = defaultdict(list), defaultdict(list), []
    reg = registry()

    for dom in domains:
        meta = reg["projects"].get(dom, {})
        vertical = meta.get("vertical") or "unlabelled"
        briefs = read(proj_dir(dom) / "briefs.json", {"briefs": {}}).get("briefs", {})
        baselines = read(proj_dir(dom) / "baselines.json", {"questions": {}})

        for b in briefs.values():
            m = measure_brief(b, baselines)
            if not m or not m.get("measured"):
                continue
            row = {"domain": dom, "vertical": vertical,
                   "form": b.get("form"), "form_key": b.get("form_key"), **m}
            rows.append(row)
            by_form[b.get("form") or "unknown"].append(row)
            by_vertical[vertical].append(row)
    return rows, by_form, by_vertical


def summarise(group):
    n = len(group)
    return {
        "briefs": n,
        "questions": sum(g["measured"] for g in group),
        "up": sum(g["up"] for g in group),
        "flat": sum(g["flat"] for g in group),
        "down": sum(g["down"] for g in group),
        "avg_delta": sum(g["avg_delta"] for g in group) / n if n else 0.0,
    }


def verdict(n, threshold):
    if n >= threshold:
        return "measured"
    if n >= max(2, threshold // 2):
        return f"n={n}, provisional"
    return f"n={n}, NOT A FINDING"


def table(title, groups, threshold, out):
    if not groups:
        return
    out.append(f"\n  {title}")
    out.append("  " + "-" * 88)
    out.append(f"  {'':<26} {'BRIEFS':>7} {'Qs':>5} {'UP':>5} {'FLAT':>5} "
               f"{'DOWN':>5} {'AVG Δ':>8}   VERDICT")
    for name, group in sorted(groups.items(),
                              key=lambda kv: -summarise(kv[1])["avg_delta"]):
        s = summarise(group)
        out.append(f"  {str(name)[:25]:<26} {s['briefs']:>7} {s['questions']:>5} "
                   f"{s['up']:>5} {s['flat']:>5} {s['down']:>5} "
                   f"{s['avg_delta']:>+8.3f}   {verdict(s['briefs'], threshold)}")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--domain")
    ap.add_argument("--json")
    a = ap.parse_args()

    cfg = cfg_mod.load()
    threshold = cfg["calibration"]["min_samples_to_report"]

    reg = registry()
    domains = [a.domain] if a.domain else sorted(reg.get("projects", {}))
    if not domains:
        print("No projects tracked yet.")
        return

    rows, by_form, by_vertical = collect(domains)

    out = ["", "=" * 92,
           "  ALKEYWORD — CALIBRATION   ·   what actually moved citations",
           "=" * 92]

    if not rows:
        out += [
            "",
            "  Nothing measurable yet. Calibration needs, for at least one brief:",
            "    1. status 'published'  (store.py set-status <domain> <key> published)",
            "    2. a probe recorded BEFORE that date",
            "    3. a probe recorded AFTER it",
            "",
            "  Until all three exist there is no before/after to compare, and this",
            "  reports nothing rather than inventing a trend.",
            "=" * 92, ""]
        print("\n".join(out))
        return

    total = summarise(rows)
    out += ["",
            f"  Published briefs measured : {total['briefs']}",
            f"  Questions with before/after: {total['questions']}",
            f"  Moved up / flat / down     : {total['up']} / {total['flat']} / {total['down']}",
            f"  Average change in citation rate: {total['avg_delta']:+.3f}",
            f"  Overall verdict            : {verdict(total['briefs'], threshold)}"]

    unmeasurable = sum(r["unmeasurable"] for r in rows)
    if unmeasurable:
        out.append(f"  ({unmeasurable} targeted questions lacked a probe on both sides "
                   f"of publication — excluded, not counted as flat.)")

    table("BY FORM", by_form, threshold, out)
    table("BY VERTICAL", by_vertical, threshold, out)

    if total["briefs"] < threshold:
        out += ["",
                f"  ⚠ Below {threshold} published briefs, treat every row above as a number,",
                "    not a prior. Do not re-rank the gap library on this yet."]
    else:
        out += ["",
                "  Forms ranking above the others here beat the built-in value order",
                "  on YOUR sites. That is the signal worth acting on."]

    out += ["=" * 92, ""]
    print("\n".join(out))

    if a.json:
        with open(a.json, "w") as f:
            json.dump({"total": total, "rows": rows,
                       "by_form": {k: summarise(v) for k, v in by_form.items()},
                       "by_vertical": {k: summarise(v) for k, v in by_vertical.items()},
                       "threshold": threshold}, f, indent=2)
        print(f"wrote {a.json}", file=sys.stderr)


if __name__ == "__main__":
    main()
