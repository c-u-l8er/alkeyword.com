#!/usr/bin/env python3
"""
Alkeyword — Stage 2a: EXPAND. Mine real queries, cross-referenced against the claim graph.

Consumes crawl.py's --json output. Seeds from what the site actually claims, mines
free autocomplete endpoints for queries people really type, then answers the question
that makes this useful: DOES THIS SITE HAVE THE MATERIAL TO ANSWER THIS?

No API key. No paid keyword data. Autocomplete returns real queries rather than
modeled volume, which is the better input for AI search anyway — the unit of demand
in a generative engine is a question, not a keyword with a number next to it.

Usage:
    python3 expand.py crawl.json [--max-seeds 12] [--json out.json]
"""

import argparse
import json
import re
import sys
import time
import urllib.parse
import urllib.request
from collections import defaultdict

UA = "Mozilla/5.0 (compatible; AlkeywordBot/0.1; +https://alkeyword.com)"

SOURCES = {
    "google": "https://suggestqueries.google.com/complete/search?client=firefox&q={}",
    "ddg": "https://duckduckgo.com/ac/?q={}&type=list",
}

# Modifiers that surface intent rather than just more nouns.
QUESTION_MODS = ["how", "what", "why", "which", "when", "is", "does", "can"]
COMMERCIAL_MODS = ["best", "vs", "alternative to", "pricing for", "review of"]
SUFFIX_MODS = ["vs", "alternatives", "pricing", "review", "for", "examples", "meaning"]

STOP = {"the", "and", "for", "with", "that", "this", "you", "your", "are", "not",
        "how", "what", "why", "which", "when", "does", "can", "is", "a", "an",
        "to", "of", "in", "on", "it", "be", "or", "do", "best", "vs"}


def suggest(query, source="google", timeout=10):
    url = SOURCES[source].format(urllib.parse.quote(query))
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8", errors="replace"))
    except Exception:
        return []
    # Both endpoints return [query, [suggestions], ...]
    if isinstance(data, list) and len(data) > 1 and isinstance(data[1], list):
        return [s for s in data[1] if isinstance(s, str)]
    return []


# ---------------------------------------------------------------- seeds


def build_seeds(crawl, max_seeds):
    """Seed from what the site actually claims — not from a generic niche guess."""
    entity = crawl["entity"]
    seeds, seen = [], set()

    def usable(t):
        """Reject fragments the heuristic extractor emits as bogus 'definitions'.

        Live run seeded 'here' (from "Here is the gap, axis by axis.") and 'each phase',
        which mined mitosis, chess and FAFSA results. A seed must carry real topical
        content, not be a sentence fragment.
        """
        words = t.split()
        content = [w for w in words if w not in STOP]
        if not content or len(content) < len(words) - 1:
            return False              # mostly stopwords
        if any(len(w) < 4 for w in content) and len(content) == 1:
            return False              # single short token
        return True

    def add(term, kind):
        t = re.sub(r"[^\w\s\-&]", "", re.sub(r"\s+", " ", term)).strip().lower()
        if 3 < len(t) < 60 and t not in seen and usable(t):
            seen.add(t)
            seeds.append({"term": t, "kind": kind})

    add(entity, "entity")

    by_type = defaultdict(list)
    for c in crawl["claims"]:
        by_type[c["type"]].append(c)

    # definition subjects are the site's own vocabulary — its best seeds
    for c in by_type.get("definition", []):
        subj = c["subject"]
        if subj and subj.lower() != entity.lower() and len(subj.split()) <= 4:
            add(subj, "term")

    # comparison claims name the competitive set the site itself acknowledges
    for c in by_type.get("comparison", []):
        for m in re.findall(r"\b(?:vs\.?|versus|unlike|compared to)\s+([A-Z][\w\- ]{2,30})",
                            c["text_span"]):
            add(m, "competitor")

    # recurring capitalized noun phrases in headings = category vocabulary
    heads = defaultdict(int)
    for p in crawl["pages"]:
        for _lvl, txt in p.get("outline", []):
            for m in re.findall(r"\b([A-Z][a-z]{3,}(?: [A-Z][a-z]{3,})?)\b", txt):
                if m.lower() not in STOP:
                    heads[m] += 1
    for term, n in sorted(heads.items(), key=lambda kv: -kv[1]):
        if n >= 3:
            add(term, "topic")

    return seeds[:max_seeds]


# ---------------------------------------------------------------- mining


def on_topic(suggestion, seed):
    """Autocomplete silently substitutes the nearest real phrase for terms it doesn't know.

    Live run: seed 'opensentience' returned 'open sentence', 'open sentence worksheet',
    'open sentences quizlet' — a maths term, not the brand. Any suggestion that has drifted
    off the seed is a different topic and must be discarded, not counted as demand.
    """
    st, qt = tokens(seed), tokens(suggestion)
    if not st:
        return False
    if st <= qt:
        return True                                   # seed survives intact
    return len(st & qt) / len(st) >= 0.6              # most of a multiword seed survives


def mine(seeds, delay=0.35, verbose=True):
    queries, drift = {}, defaultdict(lambda: [0, 0])

    def record(q, seed, mod):
        q = q.strip().lower()
        if not (5 < len(q) < 120):
            return
        drift[seed][1] += 1
        if not on_topic(q, seed):
            return
        drift[seed][0] += 1
        if q not in queries:
            queries[q] = {"query": q, "seeds": set(), "mods": set()}
        queries[q]["seeds"].add(seed)
        queries[q]["mods"].add(mod)

    for i, s in enumerate(seeds, 1):
        term = s["term"]
        variants = [(term, "bare")]
        variants += [(f"{m} {term}", m) for m in QUESTION_MODS + COMMERCIAL_MODS]
        variants += [(f"{term} {m}", m) for m in SUFFIX_MODS]

        if verbose:
            print(f"  [{i}/{len(seeds)}] {term!r} ({s['kind']}) …", file=sys.stderr)

        for v, mod in variants:
            for src in ("google", "ddg"):
                for hit in suggest(v, src):
                    record(hit, term, mod)
                time.sleep(delay)

    unknown = []
    for s in seeds:
        kept, total = drift[s["term"]]
        s["kept"], s["returned"] = kept, total
        # Nothing survived the drift guard => autocomplete has no data for this term.
        if total >= 20 and kept / total < 0.05:
            unknown.append(s["term"])

    for q in queries.values():
        q["seeds"] = sorted(q["seeds"])
        q["mods"] = sorted(q["mods"])
    return list(queries.values()), unknown


# ---------------------------------------------------------------- the useful part


def tokens(s):
    return {w for w in re.findall(r"[a-z][a-z\-]{2,}", s.lower()) if w not in STOP}


def score_material(queries, crawl):
    """For each query: does the site already have claims that could answer it?

    This is the whole point. A keyword list without this is just a keyword list.
    """
    claims = crawl["claims"]
    index = []
    for c in claims:
        index.append((tokens(c["text_span"] + " " + str(c["object"])), c))

    entity_tokens = tokens(crawl["entity"])

    for q in queries:
        qt = tokens(q["query"])
        if not qt:
            q["material"] = {"claims": 0, "types": [], "verdict": "none"}
            continue

        matched, types = [], defaultdict(int)
        for ctoks, c in index:
            overlap = qt & ctoks
            # require real topical overlap, not just the brand name appearing
            if len(overlap - entity_tokens) >= 2:
                matched.append(c)
                types[c["type"]] += 1

        strong = sum(types[t] for t in ("quantity", "quote", "definition",
                                        "comparison", "process", "credential"))
        if strong >= 5:
            verdict = "ready"
        elif strong >= 2:
            verdict = "thin"
        elif matched:
            verdict = "weak"
        else:
            verdict = "none"

        q["material"] = {
            "claims": len(matched),
            "strong": strong,
            "types": sorted(types, key=lambda t: -types[t]),
            "verdict": verdict,
            "sources": sorted({c["source_url"] for c in matched})[:4],
            "examples": [c["text_span"][:110] for c in matched[:3]],
        }
        q["is_question"] = bool(re.match(
            r"^(how|what|why|which|when|who|is|are|does|do|can|should)\b", q["query"]))
    return queries


def cluster(queries):
    """Group by dominant shared token so the output reads as topics, not a flat list."""
    groups = defaultdict(list)
    for q in queries:
        t = tokens(q["query"])
        groups[max(t, key=len) if t else "misc"].append(q)
    return sorted(groups.items(), key=lambda kv: -len(kv[1]))


# ---------------------------------------------------------------- report


def report(crawl, queries, unknown):
    W = 76
    ready = [q for q in queries if q["material"]["verdict"] == "ready"]
    thin = [q for q in queries if q["material"]["verdict"] == "thin"]
    none = [q for q in queries if q["material"]["verdict"] == "none"]
    qs = [q for q in queries if q.get("is_question")]

    print("\n" + "=" * W)
    print(f"  ALKEYWORD — RESEARCH EXPANSION   ·   {crawl['domain']}")
    print("=" * W)
    print(f"  Entity          : {crawl['entity']}")
    print(f"  Real queries    : {len(queries)}   ({len(qs)} phrased as questions)")
    print(f"  Source          : google + duckduckgo autocomplete (free, no key)")

    if unknown:
        print("\n  ⚠ AUTOCOMPLETE HAS NO DATA FOR THESE TERMS")
        print("  " + "-" * (W - 4))
        for t in unknown:
            print(f"    {t!r} — every suggestion drifted to a different topic")
        print("    Nobody is searching this term. That is a positioning finding,")
        print("    not a content one: demand has to be captured on category")
        print("    language, because the brand name itself has no search volume.")

    print("\n  MATERIAL VERDICT — can this site answer it today?")
    print("  " + "-" * (W - 4))
    print(f"  ✓ ready  {len(ready):>4}   site already has ≥5 strong claims")
    print(f"  ~ thin   {len(thin):>4}   has 2-4 — needs a few more facts")
    print(f"  ✗ none   {len(none):>4}   nothing on the site touches this")

    if ready:
        print("\n  WRITE THESE FIRST — material already on your site")
        print("  " + "-" * (W - 4))
        for q in sorted(ready, key=lambda q: -q["material"]["strong"])[:10]:
            m = q["material"]
            mark = "?" if q.get("is_question") else " "
            print(f"  {mark} {q['query']}")
            print(f"      {m['strong']} strong claims · {', '.join(m['types'][:4])}")
            for s in m["sources"][:2]:
                print(f"      ← {s[:64]}")

    if thin:
        print("\n  NEARLY THERE — gather a few more facts")
        print("  " + "-" * (W - 4))
        for q in sorted(thin, key=lambda q: -q["material"]["strong"])[:8]:
            print(f"    {q['query']}  ({q['material']['strong']} claims)")

    if none:
        print("\n  DEMAND YOU DON'T SERVE — real queries, nothing on your site")
        print("  " + "-" * (W - 4))
        for q in none[:10]:
            print(f"    {q['query']}")

    print("\n  CLUSTERS")
    print("  " + "-" * (W - 4))
    for name, group in cluster(queries)[:8]:
        r = sum(1 for g in group if g["material"]["verdict"] == "ready")
        print(f"    {name:<22} {len(group):>3} queries   {r} ready")
    print("=" * W + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("crawl_json")
    ap.add_argument("--max-seeds", type=int, default=10)
    ap.add_argument("--seeds", help="comma-separated seeds, bypassing auto-seeding. "
                                    "Use when an LLM has resolved subjects properly "
                                    "(spec §1.4) — auto-seeding inherits the heuristic "
                                    "extractor's bogus 'definition' claims.")
    ap.add_argument("--delay", type=float, default=0.35)
    ap.add_argument("--json")
    a = ap.parse_args()

    with open(a.crawl_json) as f:
        crawl = json.load(f)

    if a.seeds:
        seeds = [{"term": t.strip().lower(), "kind": "supplied"}
                 for t in a.seeds.split(",") if t.strip()]
    else:
        seeds = build_seeds(crawl, a.max_seeds)
    print(f"seeded {len(seeds)} terms from the claim graph:", file=sys.stderr)
    for s in seeds:
        print(f"  · {s['term']} ({s['kind']})", file=sys.stderr)

    queries, unknown = mine(seeds, a.delay)
    queries = score_material(queries, crawl)
    report(crawl, queries, unknown)

    if a.json:
        with open(a.json, "w") as f:
            json.dump({"domain": crawl["domain"], "entity": crawl["entity"],
                       "seeds": seeds, "unknown_terms": unknown,
                       "queries": queries}, f, indent=2)
        print(f"wrote {a.json}", file=sys.stderr)


if __name__ == "__main__":
    main()
