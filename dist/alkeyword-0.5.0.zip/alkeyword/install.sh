#!/usr/bin/env bash
# Alkeyword installer — copies the skill into your Claude Code skills directory.
#
#   ./install.sh              install for the current user (~/.claude/skills)
#   ./install.sh --project    install into ./.claude/skills for this repo only
#
# No dependencies. The engine is Python 3 stdlib only.

set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/skills/alkeyword"

if [ "${1:-}" = "--project" ]; then
    DEST="$PWD/.claude/skills/alkeyword"
    SCOPE="this project"
else
    DEST="$HOME/.claude/skills/alkeyword"
    SCOPE="your user account"
fi

if [ ! -f "$SRC/SKILL.md" ]; then
    echo "error: can't find the skill at $SRC" >&2
    echo "Run this script from inside the unpacked alkeyword directory." >&2
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
    echo "error: python3 not found — the crawl engine needs it (stdlib only, no packages)." >&2
    exit 1
fi

if [ -e "$DEST" ]; then
    echo "Alkeyword is already installed at:"
    echo "  $DEST"
    printf 'Overwrite it? [y/N] '
    read -r reply
    case "$reply" in
        [yY]*) rm -rf "$DEST" ;;
        *) echo "Left it alone. Nothing changed."; exit 0 ;;
    esac
fi

mkdir -p "$(dirname "$DEST")"
cp -R "$SRC" "$DEST"

echo
echo "Installed for $SCOPE:"
echo "  $DEST"
echo
echo "Start a new Claude Code session and try:"
echo "  /alkeyword example.com"
echo
echo "Or just ask: \"what does AI search say about example.com?\""
echo
echo "The crawl is free and runs locally. Model work uses your Claude subscription."
