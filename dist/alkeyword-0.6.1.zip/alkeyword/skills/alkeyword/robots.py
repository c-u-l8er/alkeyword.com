#!/usr/bin/env python3
"""
robots.txt evaluation, RFC 9309, implemented here rather than delegated.

## Why this file exists

v0.6.0 replaced a hand-rolled robots check with `urllib.robotparser` and a comment
crediting the stdlib with "precedence, longest-match and wildcard handling". That
comment was true on the interpreter it was written on and false on most others.
Measured across the five Pythons installed on the build machine:

    3.9.25    longest_match=False  wildcard=False  end_anchor=False
    3.10.20   longest_match=False  wildcard=False  end_anchor=False
    3.11.15   longest_match=False  wildcard=False  end_anchor=False
    3.12.13   longest_match=False  wildcard=False  end_anchor=False
    3.13.14   longest_match=True   wildcard=True   end_anchor=True

`urllib.robotparser` gained `best_match` precedence, `translate_pattern` and
`normalize_uri` somewhere in the 3.13 line. Before that it is first-matching-prefix
with `str.startswith`, so:

  * `Disallow: /` + `Allow: /docs/` reads as "/docs/ is blocked" — a restriction
    reported where none exists
  * `Disallow: /a/*/c` matches nothing real — a restriction missed
  * `Disallow: /*.pdf$` behaves as a prefix and swallows `/f.pdf.html`

Any of those turns into a published finding about somebody's site. That is the
v0.5.0 error class exactly — a claim about robots.txt that was not observed —
returning in a subtler form: *we claim standards-level interpretation because the
stdlib sounds authoritative*. The fix is not a narrower comment. A tool whose
findings change with the user's patch release is not reproducible, and
`config_fingerprint` cannot see the difference.

So the rules live here, in about eighty lines of stdlib, and the artifact records
which engine produced the result.

## What is implemented

RFC 9309 §2.2.2 (path matching) and §2.2.1 (group selection):

  * `*` matches any sequence of characters, spanning `/`
  * `$` at the end anchors the match to the end of the path
  * the most specific rule wins, measured by the length of the pattern; `Allow`
    wins a tie, which is what makes `Allow: /docs/` under `Disallow: /` work
  * exactly one group applies: the longest matching user-agent token,
    case-insensitively, falling back to `*`; groups do not merge
  * an empty `Disallow:` is an allow
  * `/robots.txt` is always fetchable
"""

import re

ENGINE = "alkeyword-rfc9309/1"


def _translate(pattern):
    """robots path pattern -> regex. Only * and $ are special."""
    out, anchored = [], pattern.endswith("$")
    if anchored:
        pattern = pattern[:-1]
    for ch in pattern:
        out.append(".*" if ch == "*" else re.escape(ch))
    return re.compile("".join(out) + ("$" if anchored else ""))


class Rule:
    __slots__ = ("pattern", "allow", "rx", "specificity")

    def __init__(self, pattern, allow):
        self.pattern = pattern
        self.allow = allow
        self.rx = _translate(pattern)
        # RFC 9309: specificity is the length of the pattern, "$" and "*" included.
        self.specificity = len(pattern)

    def matches(self, path):
        return self.rx.match(path) is not None


class Rules:
    """Parsed robots.txt. Construct with Rules.parse(text)."""

    def __init__(self, groups, sitemaps):
        self.groups = groups          # {lowercase agent token: [Rule]}
        self.sitemaps = sitemaps

    # ------------------------------------------------------------ parsing

    @classmethod
    def parse(cls, text):
        groups, sitemaps = {}, []
        current = []          # agent tokens this block applies to
        starting_group = True # a User-agent line after rules begins a NEW group

        for raw in (text or "").splitlines():
            line = raw.split("#", 1)[0].strip()
            if not line or ":" not in line:
                continue
            field, _, value = line.partition(":")
            field, value = field.strip().lower(), value.strip()

            if field == "user-agent":
                if not starting_group:
                    current = []
                    starting_group = True
                current.append(value.lower())
                groups.setdefault(value.lower(), [])
            elif field in ("allow", "disallow"):
                starting_group = False
                if not current:
                    continue          # rules before any user-agent line: ignored
                # "Disallow:" with an empty value means allow everything.
                allow = field == "allow" or value == ""
                if field == "disallow" and value == "":
                    value = "/"
                    allow = True
                for agent in current:
                    groups[agent].append(Rule(value, allow))
            elif field == "sitemap":
                sitemaps.append(value)

        return cls(groups, sitemaps)

    # ------------------------------------------------------------ matching

    def group_for(self, agent):
        """RFC 9309 §2.2.1 — one group, longest matching agent token, no merging."""
        a = (agent or "").lower()
        best, best_len = None, -1
        for token, rules in self.groups.items():
            if token == "*":
                continue
            if token and token in a and len(token) > best_len:
                best, best_len = rules, len(token)
        if best is not None:
            return best
        return self.groups.get("*")

    def allows(self, agent, path):
        rules = self.group_for(agent)
        if not rules:
            return True                       # no applicable group: unrestricted
        if path.startswith("/robots.txt"):
            return True

        winner = None
        for r in rules:
            if not r.matches(path):
                continue
            if winner is None or r.specificity > winner.specificity:
                winner = r
            elif r.specificity == winner.specificity and r.allow:
                winner = r                    # Allow wins ties
        return True if winner is None else winner.allow


def evaluate(text, agents, probe_paths=("/", "/docs/", "/blog/", "/about")):
    """Per-agent evidence: blocked at the root, or restricted somewhere below it.

    Three states, kept apart because they mean different things to a site owner:
      blocked     cannot fetch "/" — nothing downstream matters
      restricted  can fetch "/" but not everything under it
      neither     no rule observed that denies any probed path

    `probe_paths` is a sample, not an enumeration, and the caller should say so.
    """
    rules = Rules.parse(text)
    blocked, restricted = [], {}
    for agent in agents:
        verdicts = {p: rules.allows(agent, p) for p in probe_paths}
        if not verdicts["/"]:
            blocked.append(agent)
        elif not all(verdicts.values()):
            restricted[agent] = sorted(p for p, ok in verdicts.items() if not ok)
    return {
        "engine": ENGINE,
        "blocked": sorted(set(blocked)),
        "restricted": restricted,
        "sitemaps": rules.sitemaps,
        "rules": rules,
    }
