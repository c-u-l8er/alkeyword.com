#!/usr/bin/env python3
"""
Alkeyword — configuration, with guardrails on the values that aren't preferences.

Most settings are yours to tune. A few are not: the volume cap and the form
material requirements are what keep this tool away from the pattern Google's spam
policy names — scaled content abuse, introduced with the March 2024 spam update,
which targets producing many pages primarily to manipulate rankings "no matter
how it's created". Those are CLAMPED, not merely defaulted; a config that tries
to exceed them is corrected and the correction is reported.

That is a deliberate choice. A safety constraint you can silently delete is not a
safety constraint.

    config.py show          # effective config, with any clamps applied
    config.py path          # where the file lives
    config.py init          # write a commented starter file
    config.py set a.b 5     # set one value
"""

import argparse
import hashlib
import json
import os
import pathlib
import sys

ROOT = pathlib.Path(os.environ.get("ALKEYWORD_HOME",
                                   pathlib.Path.home() / ".alkeyword"))
# Kept for the CLI's messages. Runtime lookups go through config_path(), which
# re-reads ALKEYWORD_HOME so a test can redirect it.
CONFIG_PATH = ROOT / "config.json"

DEFAULTS = {
    "crawl": {"max_pages": 40, "delay": 0.4, "headless_word_threshold": 100},
    "expand": {"max_seeds": 10, "delay": 0.35,
               "ready_strong_claims": 5, "thin_strong_claims": 2,
               "drift_overlap": 0.6},
    "brief": {"max_briefs": 8, "cluster_min_strong": 2, "cluster_jaccard": 0.5},
    "probe": {"runs": 3, "engine": "perplexity", "cache_weeks": 1},
    "generate": {"max_pieces_per_cycle": 6, "require_human_review": True},
    "forms": {
        "comparison": {"req": {"comparison": 2, "attribute": 6, "quantity": 2}, "value": 6},
        "statistics": {"req": {"quantity": 5}, "value": 5},
        "faq":        {"req": {"question": 5}, "value": 4},
        "howto":      {"req": {"process": 1, "attribute": 3}, "value": 3},
        "entity":     {"req": {"credential": 3}, "value": 2},
        "glossary":   {"req": {"definition": 3, "attribute": 4}, "value": 1},
    },
    "calibration": {"min_samples_to_report": 5},
}

# Ceilings and floors that config cannot cross. Each exists for a stated reason.
GUARDS = {
    "generate.max_pieces_per_cycle": (
        "max", 12,
        "Volume is the penalty pattern. Raising this past 12/cycle recreates the "
        "shape Google's scaled-content-abuse policy describes."),
    "generate.require_human_review": (
        "must_be", True,
        "Unreviewed automated publishing is where both brand risk and Google risk live."),
    "brief.cluster_min_strong": (
        "min", 2,
        "Below 2 strong claims a 'brief' carries no raw material and becomes a "
        "keyword list with extra steps."),
    "expand.ready_strong_claims": (
        "min", 3,
        "Marking a query 'ready' on fewer than 3 strong claims sends the user to "
        "write a page they have no material for."),
    "probe.runs": (
        "min", 2,
        "A single sample cannot produce a rate, and rates-not-binaries is the whole "
        "reporting discipline."),
}

MIN_FORM_REQ = 2   # every form must demand at least this many claims in total


def deep_merge(base, over):
    out = dict(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def get_path(cfg, dotted):
    node = cfg
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            return None
        node = node[part]
    return node


def set_path(cfg, dotted, value):
    parts = dotted.split(".")
    node = cfg
    for p in parts[:-1]:
        node = node.setdefault(p, {})
    node[parts[-1]] = value


def apply_guards(cfg):
    """Clamp the safety-critical values. Returns (config, [corrections])."""
    notes = []
    for dotted, (kind, limit, why) in GUARDS.items():
        cur = get_path(cfg, dotted)
        if cur is None:
            continue
        if kind == "max" and isinstance(cur, (int, float)) and cur > limit:
            set_path(cfg, dotted, limit)
            notes.append(f"{dotted}: {cur} → {limit} (clamped). {why}")
        elif kind == "min" and isinstance(cur, (int, float)) and cur < limit:
            set_path(cfg, dotted, limit)
            notes.append(f"{dotted}: {cur} → {limit} (clamped). {why}")
        elif kind == "must_be" and cur is not limit:
            set_path(cfg, dotted, limit)
            notes.append(f"{dotted}: {cur} → {limit} (forced). {why}")

    for name, spec in (cfg.get("forms") or {}).items():
        req = spec.get("req") or {}
        total = sum(v for v in req.values() if isinstance(v, (int, float)))
        if total < MIN_FORM_REQ:
            spec["req"] = dict(DEFAULTS["forms"].get(name, {}).get("req", {"attribute": 2}))
            notes.append(
                f"forms.{name}.req demanded {total} claims → restored default. "
                f"A form with no material requirement disables the refusal rule.")
    return cfg, notes


def _root():
    """Re-read ALKEYWORD_HOME per call so tests can point it at a temp dir."""
    return pathlib.Path(os.environ.get("ALKEYWORD_HOME",
                                       pathlib.Path.home() / ".alkeyword"))


def config_path():
    return _root() / "config.json"


def load(verbose=False):
    """Effective config: defaults <- user file, then guards. Never raises."""
    user = {}
    path = config_path()
    if path.exists():
        try:
            user = json.loads(path.read_text())
        except json.JSONDecodeError as e:
            print(f"warning: {path} is not valid JSON ({e}); using defaults.",
                  file=sys.stderr)
    cfg, notes = apply_guards(deep_merge(DEFAULTS, user))
    if notes and verbose:
        print("config corrections applied:", file=sys.stderr)
        for n in notes:
            print(f"  · {n}", file=sys.stderr)
    cfg["_corrections"] = notes
    return cfg


# ---------------------------------------------------------------- precedence

def resolve(dotted, cli=None, cfg=None):
    """One rule for every runtime value: CLI > user config > application default.

    Before this existed, config.py said crawl.max_pages=40, crawl.py's CLI said
    60, and crawl.py never imported config — so the configuration layer described
    a program that did not run. Two disagreeing defaults is also how a bug-fix
    recrawl silently becomes a policy change, which is unreadable afterwards
    because the extractor delta and the depth delta are mixed together.

    `cli=None` means "not supplied". Every CLI that reads a configurable value
    must therefore default its argument to None rather than to a literal, so that
    "the user asked for the default" and "the user asked for 40" stay distinct.
    """
    if cli is not None:
        return cli
    node = cfg if cfg is not None else load()
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            raise KeyError(f"unknown config key: {dotted}")
        node = node[part]
    return node


def fingerprint(cfg=None):
    """Stable short hash of the values that change what a crawl means.

    Recorded into every artifact so a corpus can be checked for having been
    produced under one configuration. Deliberately excludes `delay`, which
    affects politeness and wall-clock but not the content of the result.
    """
    cfg = cfg if cfg is not None else load()
    material = {
        "crawl": {k: v for k, v in cfg.get("crawl", {}).items() if k != "delay"},
        "expand": {k: cfg.get("expand", {}).get(k)
                   for k in ("ready_strong_claims", "thin_strong_claims")},
        "brief": {k: cfg.get("brief", {}).get(k)
                  for k in ("cluster_min_strong", "cluster_jaccard")},
        "forms": cfg.get("forms", {}),
    }
    blob = json.dumps(material, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode()).hexdigest()[:12]


# ---------------------------------------------------------------- cli


def cmd_show(a):
    cfg = load()
    notes = cfg.pop("_corrections", [])
    print(json.dumps(cfg, indent=2))
    if notes:
        print("\ncorrections applied:", file=sys.stderr)
        for n in notes:
            print(f"  · {n}", file=sys.stderr)


def cmd_path(a):
    print(CONFIG_PATH)
    print("exists" if CONFIG_PATH.exists() else "not created yet — config.py init")


def cmd_init(a):
    if CONFIG_PATH.exists() and not a.force:
        print(f"{CONFIG_PATH} already exists. Use --force to overwrite.", file=sys.stderr)
        sys.exit(1)
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    starter = {
        "crawl": {"max_pages": DEFAULTS["crawl"]["max_pages"]},
        "probe": {"runs": DEFAULTS["probe"]["runs"]},
        "brief": {"max_briefs": DEFAULTS["brief"]["max_briefs"]},
    }
    CONFIG_PATH.write_text(json.dumps(starter, indent=2) + "\n")
    print(f"wrote {CONFIG_PATH}")
    print("Anything omitted falls back to defaults. Some values are clamped —")
    print("run `config.py show` to see the effective config.")


def cmd_set(a):
    user = {}
    if CONFIG_PATH.exists():
        try:
            user = json.loads(CONFIG_PATH.read_text())
        except json.JSONDecodeError:
            print(f"{CONFIG_PATH} is not valid JSON — fix or delete it first.",
                  file=sys.stderr)
            sys.exit(1)
    try:
        value = json.loads(a.value)          # numbers, bools, lists
    except json.JSONDecodeError:
        value = a.value                      # bare string
    set_path(user, a.key, value)
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(user, indent=2) + "\n")

    effective = get_path(load(), a.key)
    if effective != value:
        print(f"{a.key} = {value!r} written, but clamped to {effective!r}.")
        for n in load()["_corrections"]:
            if n.startswith(a.key):
                print(f"  {n.split('. ', 1)[-1]}")
    else:
        print(f"{a.key} = {effective!r}")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("show").set_defaults(fn=cmd_show)
    sub.add_parser("path").set_defaults(fn=cmd_path)
    s = sub.add_parser("init"); s.add_argument("--force", action="store_true")
    s.set_defaults(fn=cmd_init)
    s = sub.add_parser("set"); s.add_argument("key"); s.add_argument("value")
    s.set_defaults(fn=cmd_set)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
