#!/usr/bin/env python3
"""
Corpus admissibility. One place that decides whether a set of crawl artifacts may
be aggregated together.

The problem this exists for: fixing the crawler invalidated every committed run,
and nothing could tell an old artifact from a new one — they were structurally
interchangeable. So "regenerate everything" was a thing somebody had to remember,
and forgetting it produced a report averaged across two different instruments
with no sign that anything was wrong.

This turns that into something the build knows. `require_uniform()` refuses:

  * artifacts older than the schema this code speaks
  * artifacts newer than it (a corpus from a future crawler is not readable
    just because most of the keys still parse)
  * a mixed corpus — more than one crawler version or one config fingerprint
    across the set

The last one matters most and is the easiest to hit: a partial recrawl leaves
half the directory current and half stale, which is precisely the state that
looks fine and averages nonsense.
"""

import json
import sys

SCHEMA = 3   # the schema this codebase reads; must match crawl.CRAWL_SCHEMA


class CorpusError(Exception):
    pass


def read(path):
    with open(path) as fh:
        return json.load(fh)


def describe(doc, path):
    return {
        "path": path,
        "schema": doc.get("crawl_schema"),
        "version": doc.get("alkeyword_version"),
        "fingerprint": doc.get("config_fingerprint"),
    }


def require_uniform(docs, *, what="corpus"):
    """docs: [(path, parsed_json)]. Raises CorpusError with a usable message."""
    if not docs:
        raise CorpusError(f"{what}: no artifacts found")

    stamps = [describe(d, p) for p, d in docs]

    unstamped = [s["path"] for s in stamps if s["schema"] is None]
    if unstamped:
        raise CorpusError(
            f"{what}: {len(unstamped)} artifact(s) carry no crawl_schema, so they "
            f"predate schema {SCHEMA} and cannot be compared with it.\n"
            f"  first: {unstamped[0]}\n"
            f"  These are v0.5.0-era files. They are kept in prototype/corpus/v0.5.0/\n"
            f"  as evidence of the previous instrument; recrawl rather than mixing.")

    wrong = [s for s in stamps if s["schema"] != SCHEMA]
    if wrong:
        raise CorpusError(
            f"{what}: schema mismatch. This code reads schema {SCHEMA}; found "
            f"{sorted({s['schema'] for s in wrong})}.\n  first: {wrong[0]['path']}")

    versions = {s["version"] for s in stamps}
    if len(versions) > 1:
        raise CorpusError(
            f"{what}: mixed crawler versions {sorted(versions)}. A partial recrawl "
            f"leaves a directory that looks complete and averages two instruments.")

    prints = {s["fingerprint"] for s in stamps}
    if len(prints) > 1:
        by = {}
        for s in stamps:
            by.setdefault(s["fingerprint"], []).append(s["path"])
        detail = "\n".join(f"    {fp}: {len(ps)} file(s), e.g. {ps[0]}"
                           for fp, ps in sorted(by.items()))
        raise CorpusError(
            f"{what}: mixed config fingerprints — the crawls were not run under one "
            f"configuration, so differences between them are not attributable.\n{detail}")

    return {"schema": SCHEMA, "version": versions.pop(), "fingerprint": prints.pop(),
            "count": len(docs)}


def guard(docs, *, what="corpus"):
    """require_uniform, but exits with a message instead of a traceback."""
    try:
        return require_uniform(docs, what=what)
    except CorpusError as e:
        print(f"refusing to build: {e}", file=sys.stderr)
        sys.exit(2)
