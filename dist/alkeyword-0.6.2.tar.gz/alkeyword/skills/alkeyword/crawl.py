#!/usr/bin/env python3
"""
Alkeyword prototype — Stage 1: CRAWL + claim extraction.

Input: a bare domain. Output: a claim graph + the "free findings" from spec §1.7.

Stdlib only. No install step.

NOTE ON FIDELITY: claim extraction here is deterministic/heuristic (regex + structure)
so the *shape* of the graph is inspectable and the pipeline is verifiable without
spending tokens. Production extraction (spec §1.4) would be LLM-based and would
resolve subjects properly. This prototype answers "what does the raw material on a
real site actually look like?", not "is the extractor good?".

Usage:
    python3 crawl.py <domain> [--max-pages N] [--json out.json] [--delay S]
"""

import argparse
import gzip
import json
import pathlib
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from html.parser import HTMLParser

VERSION = "0.6.2"

# Bumped whenever the MEANING of crawl output changes, not merely its contents.
# 1 -> 2: canonical became an observation rather than an assumption, claim anchors
#         became the nearest preceding heading rather than the page's last, and
#         robots became per-crawler scope rather than one boolean. A schema-1
#         artifact and a schema-2 artifact are not comparable, and before this
#         existed nothing downstream could tell them apart.
# 2 -> 3: robots interpretation moved off urllib.robotparser, whose rule semantics
#         differ across Python patch releases (3.9-3.12 have no longest-match, no
#         wildcards, no end anchors; 3.13.14 has all three). A schema-2 artifact
#         therefore means "whatever this interpreter happened to do"; a schema-3
#         artifact means RFC 9309, and records robots_engine to say so.
CRAWL_SCHEMA = 3

UA = f"AlkeywordBot/{VERSION} (+https://alkeyword.com; site-owner analysis)"

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import robots as robots_mod

try:
    import config as cfg_mod
except Exception:                       # config is optional, never fatal
    cfg_mod = None


def _cfg(dotted, cli=None, fallback=None):
    """CLI > user config > application default, with the default in config.py."""
    if cli is not None:
        return cli
    if cfg_mod is not None:
        try:
            return cfg_mod.resolve(dotted)
        except Exception:
            pass
    return fallback

AI_CRAWLERS = [
    "GPTBot", "ClaudeBot", "Claude-Web", "PerplexityBot",
    "OAI-SearchBot", "Google-Extended", "CCBot", "anthropic-ai",
]

SKIP_EXT = re.compile(
    r"\.(pdf|zip|tar|gz|png|jpe?g|gif|svg|webp|ico|mp4|mp3|css|js|json|xml|woff2?|ttf)$", re.I
)

# ---------------------------------------------------------------- data model


@dataclass
class Page:
    url: str
    status: int = 0
    title: str = ""
    meta_description: str = ""
    lang: str = ""
    outline: list = field(default_factory=list)      # [(level, text)]
    blocks: list = field(default_factory=list)       # [(tag, text)]
    body_text: str = ""
    schema_blocks: list = field(default_factory=list)
    internal_links_out: list = field(default_factory=list)
    external_links_out: list = field(default_factory=list)
    images_no_alt: int = 0
    word_count: int = 0
    render_mode: str = "static"
    needs_headless: bool = False
    canonical: str = None            # as declared on the page, or None if absent
    canonical_resolved: str = None   # absolutised + normalised for comparison


@dataclass
class Claim:
    id: str
    type: str
    subject: str
    predicate: str
    object: str
    text_span: str
    source_url: str
    source_anchor: str
    confidence: float


# ---------------------------------------------------------------- html parsing

BLOCK_TAGS = {"p", "li", "td", "th", "dd", "dt", "blockquote", "figcaption",
              "h1", "h2", "h3", "h4", "h5", "h6", "div", "section", "article"}


class Extractor(HTMLParser):
    """Collects headings, block-level text, JSON-LD, links, meta."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.title = ""
        self.meta_description = ""
        self.lang = ""
        self.outline = []
        self.blocks = []          # (tag, text)
        self.schema_blocks = []
        self.links = []
        self.canonical = None      # declared <link rel=canonical> href, verbatim
        self.images_no_alt = 0
        self.has_script = False

        self._skip_depth = 0      # inside script/style/nav-ish
        self._in_title = False
        self._in_ld = False
        self._ld_buf = []
        self._cur_tag = None
        self._buf = []

    # -- helpers
    def _flush(self):
        if self._cur_tag and self._buf:
            text = re.sub(r"\s+", " ", "".join(self._buf)).strip()
            if text:
                if self._cur_tag.startswith("h") and len(self._cur_tag) == 2:
                    self.outline.append((int(self._cur_tag[1]), text))
                self.blocks.append((self._cur_tag, text))
        self._buf = []
        self._cur_tag = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in ("script", "style", "noscript"):
            if tag == "script":
                self.has_script = True
                if a.get("type", "").lower() == "application/ld+json":
                    self._in_ld = True
                    self._ld_buf = []
                    return
            self._skip_depth += 1
            return
        if self._skip_depth:
            return

        if tag == "html":
            self.lang = a.get("lang", "")
        elif tag == "title":
            self._in_title = True
        elif tag == "meta":
            name = (a.get("name") or a.get("property") or "").lower()
            if name in ("description", "og:description") and not self.meta_description:
                self.meta_description = a.get("content", "").strip()
        elif tag == "link":
            # Canonical is captured as an OBSERVATION, not a boolean. v0.5.0 never
            # read this tag at all, yet its duplicate-URL findings asserted "no
            # canonical" — a conclusion with nothing under it. What a duplicate
            # group needs is what each URL actually declared, so that agreement,
            # disagreement and absence stay three distinct findings.
            rels = (a.get("rel") or "").lower().split()
            if "canonical" in rels and a.get("href") and self.canonical is None:
                self.canonical = a["href"].strip()
        elif tag == "a" and a.get("href"):
            self.links.append(a["href"].strip())
        elif tag == "img":
            if not a.get("alt", "").strip():
                self.images_no_alt += 1
        elif tag in BLOCK_TAGS:
            self._flush()
            self._cur_tag = tag
        elif tag in ("br",):
            self._buf.append(" ")

    def handle_endtag(self, tag):
        if tag == "script" and self._in_ld:
            raw = "".join(self._ld_buf).strip()
            if raw:
                try:
                    self.schema_blocks.append(json.loads(raw))
                except Exception:
                    pass
            self._in_ld = False
            return
        if tag in ("script", "style", "noscript"):
            self._skip_depth = max(0, self._skip_depth - 1)
            return
        if self._skip_depth:
            return
        if tag == "title":
            self._in_title = False
        elif tag in BLOCK_TAGS and tag == self._cur_tag:
            self._flush()

    def handle_data(self, data):
        if self._in_ld:
            self._ld_buf.append(data)
            return
        if self._skip_depth:
            return
        if self._in_title:
            self.title += data
        elif self._cur_tag:
            self._buf.append(data)

    def close(self):
        super().close()
        self._flush()


# ---------------------------------------------------------------- fetching


def fetch(url, timeout=20):
    req = urllib.request.Request(
        url, headers={"User-Agent": UA, "Accept-Encoding": "gzip", "Accept": "text/html,*/*"}
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            if r.headers.get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            ctype = r.headers.get("Content-Type", "")
            charset = "utf-8"
            m = re.search(r"charset=([\w-]+)", ctype, re.I)
            if m:
                charset = m.group(1)
            return r.status, ctype, raw.decode(charset, errors="replace"), r.url
    except urllib.error.HTTPError as e:
        return e.code, "", "", url
    except Exception:
        return 0, "", "", url


def normalize_url(url):
    """Canonicalize so bare-origin and origin+'/' aren't counted as two pages.

    Without this, inbound-link counts undercount and every homepage looks
    orphaned. Found by comparing a live crawl against the raw href dump.
    """
    url, _ = urllib.parse.urldefrag(url)
    p = urllib.parse.urlsplit(url)
    path = p.path or "/"
    if path != "/" and path.endswith("/"):
        path = path.rstrip("/")
    netloc = p.netloc.lower()
    if netloc.endswith(":443") and p.scheme == "https":
        netloc = netloc[:-4]
    return urllib.parse.urlunsplit((p.scheme, netloc, path, p.query, ""))


def evaluate_robots(body, origin):
    """Per-crawler robots evidence. Rules live in robots.py, deliberately.

    v0.6.0 delegated this to urllib.robotparser and credited it with longest-match,
    wildcard and end-anchor handling. That is true on 3.13 and false on 3.9-3.12,
    where the parser is first-matching-prefix with str.startswith — so the same
    robots.txt produced different findings depending on the user's patch release.
    See robots.py for the measurements. The rules are implemented locally now, and
    the artifact records which engine produced the verdict.

    Returns blocked / restricted / neither per crawler. `restricted` carries the
    probed paths that were denied, and the probe list is a sample rather than an
    enumeration of the site — callers must not report it as exhaustive.
    """
    r = robots_mod.evaluate(body, AI_CRAWLERS)
    rules = r["rules"]
    return {
        "engine": r["engine"],
        "blocked": r["blocked"],
        "restricted": {a: {"denied": denied,
                           "allows": (lambda u, _a=a: rules.allows(
                               _a, urllib.parse.urlsplit(u).path or "/"))}
                       for a, denied in r["restricted"].items()},
        "sitemaps": r["sitemaps"],
    }


def check_robots(origin):
    """Returns (blocked, sitemaps, {agent: [denied paths]}) — see evaluate_robots."""
    status, _, body, _ = fetch(urllib.parse.urljoin(origin, "/robots.txt"))
    if status != 200 or not body:
        return [], [], {}
    r = evaluate_robots(body, origin)
    return r["blocked"], r["sitemaps"], {a: v["denied"]
                                        for a, v in r["restricted"].items()}


def urls_from_sitemap(sm_url, origin, depth=0, seen=None):
    if depth > 2:
        return []
    seen = seen if seen is not None else set()
    if sm_url in seen:
        return []
    seen.add(sm_url)
    status, _, body, _ = fetch(sm_url)
    if status != 200 or not body:
        return []
    locs = re.findall(r"<loc>\s*([^<]+?)\s*</loc>", body, re.I)
    if "<sitemapindex" in body.lower():
        out = []
        for loc in locs[:20]:
            out.extend(urls_from_sitemap(loc, origin, depth + 1, seen))
        return out
    return [u for u in locs if u.startswith(origin)]


# ---------------------------------------------------------------- claims

SENT_SPLIT = re.compile(r"(?<=[.!?])\s+(?=[A-Z\"'(])")
QUANTITY = re.compile(
    r"(?:[$£€]\s?\d[\d,]*(?:\.\d+)?(?:\s?[kKmMbB])?"          # currency
    r"|\d[\d,]*(?:\.\d+)?\s?%"                                  # percent
    r"|\b\d[\d,]*(?:\.\d+)?\s?(?:x|×)\b"                        # multiplier
    r"|\b\d{4}\b(?=\s|,|\.|$)"                                  # year
    r"|\b\d[\d,]*(?:\.\d+)?\s?(?:ms|s|sec|min|hours?|days?|weeks?|months?|years?"
    r"|GB|MB|TB|KB|req/s|ops/s|users?|customers?|companies|teams?|countries|languages?"
    r"|tests?|laws?|nodes?|pages?|projects?|models?)\b)"
)
DEFINITION = re.compile(
    r"^(?P<subj>[A-Z][\w &./'\-]{2,60}?)\s+(?P<pred>is an?|is the|refers to|means|stands for)\s+(?P<obj>.{15,300})$"
)
COMPARISON = re.compile(r"\b(?:vs\.?|versus|compared (?:to|with)|unlike|instead of|rather than|better than|faster than)\b", re.I)
CREDENTIAL = re.compile(
    r"\b(?:ISO\s?\d+|SOC\s?2|HIPAA|GDPR|PCI[- ]DSS|certified|accredited|award[- ]winning|"
    r"trusted by|partnered with|backed by|patent(?:ed)?|open[- ]source|MIT[- ]licen[cs]ed)\b", re.I
)
PROCESS_STEP = re.compile(r"^(?:step\s*\d+|\d+[.)]\s|first|second|third|then|next|finally)\b", re.I)
QUOTE = re.compile(r"[“\"](.{25,400}?)[”\"]")
BOILERPLATE = re.compile(
    r"^(?:copyright|©|all rights reserved|privacy policy|terms|cookie|sign in|log in|"
    r"menu|skip to|subscribe|follow us|share|back to top)\b", re.I
)


def sentences(text):
    for s in SENT_SPLIT.split(text):
        s = s.strip()
        if 20 <= len(s) <= 400 and not BOILERPLATE.match(s):
            yield s


def extract_claims(page, entity_name, seq):
    """Heuristic claim extraction. Returns list[Claim].

    Anchors are tracked, not computed after the fact. The previous version asked
    an `anchor_for(i)` helper for "the nearest preceding heading", and that helper
    ignored `i`, walked the whole outline and returned the LAST heading on the
    page — so every claim on a multi-heading page cited the wrong section. It was
    always called as `anchor_for(0)`, so there was never an index to honour.

    The helper is gone rather than repaired. `_flush()` appends headings to both
    `outline` and `blocks`, so walking `page.blocks` in document order and holding
    the most recent `h*` gives the true nearest-preceding heading with no
    reconstruction and nothing to get out of step. Claims that do not come from
    the HTML flow say so instead of borrowing a heading they were never under.
    """
    claims = []
    cur_anchor = [""]          # nearest preceding heading, as the block walk sees it

    def add(ctype, subj, pred, obj, span, conf, anchor=None):
        seq[0] += 1
        claims.append(Claim(
            id=f"c{seq[0]:04d}", type=ctype, subject=subj or entity_name,
            predicate=pred, object=obj[:200], text_span=span[:300],
            source_url=page.url,
            source_anchor=(cur_anchor[0] if anchor is None else anchor)[:80],
            confidence=conf,
        ))

    # -- from JSON-LD (highest confidence)
    #
    # These come out of a <script type="application/ld+json"> payload, which sits
    # outside the heading structure entirely. They are anchored to "schema:" rather
    # than to whichever heading happened to be nearby, because inventing a section
    # for them is the same error the block walk just stopped making.
    for block in page.schema_blocks:
        for node in _iter_ld(block):
            t = node.get("@type")
            t = t[0] if isinstance(t, list) and t else t
            if not isinstance(t, str):
                continue
            if t in ("Organization", "Corporation", "LocalBusiness", "Product", "SoftwareApplication"):
                nm = node.get("name")
                if isinstance(nm, str):
                    add("entity", nm, "is_a", t, f"schema:{t} name={nm}", 0.95, anchor="schema:")
                desc = node.get("description")
                if isinstance(desc, str) and len(desc) > 20:
                    add("attribute", nm or entity_name, "described_as", desc, desc, 0.9, anchor="schema:")
            elif t == "FAQPage":
                for q in node.get("mainEntity", []) or []:
                    if isinstance(q, dict) and isinstance(q.get("name"), str):
                        add("question", entity_name, "answers", q["name"], q["name"], 0.95, anchor="schema:FAQPage")
            elif t == "DefinedTerm" and isinstance(node.get("name"), str):
                add("definition", node["name"], "defined_as",
                    str(node.get("description", ""))[:200], node["name"], 0.95,
                    anchor="schema:DefinedTerm")
            elif t == "HowTo":
                steps = node.get("step", []) or []
                if len(steps) >= 3:
                    add("process", node.get("name", entity_name), "has_steps",
                        f"{len(steps)} steps", str(node.get("name", ""))[:200], 0.95,
                        anchor="schema:HowTo")

    # -- headings that are questions
    #
    # The heading is the claim, so it anchors to itself rather than to whatever
    # heading precedes it.
    for lvl, txt in page.outline:
        if txt.rstrip().endswith("?") and len(txt) > 10:
            add("question", entity_name, "answers", txt, txt, 0.8, anchor=txt)

    # -- block-level
    ordered_steps = 0
    for tag, text in page.blocks:
        # Headings arrive here in document order (see _flush), so holding the last
        # one seen IS the nearest preceding heading for everything that follows.
        if tag.startswith("h") and len(tag) == 2 and tag[1].isdigit():
            cur_anchor[0] = text
            continue
        if BOILERPLATE.match(text) or len(text) < 15:
            continue

        if tag == "blockquote" and len(text) > 25:
            add("quote", entity_name, "quotes", text, text, 0.85)
            continue

        if tag == "li" and PROCESS_STEP.match(text):
            ordered_steps += 1

        for sent in sentences(text):
            fired = False

            m = DEFINITION.match(sent)
            if m and len(m.group("subj").split()) <= 6:
                add("definition", m.group("subj"), "defined_as", m.group("obj"), sent, 0.7)
                fired = True

            qs = QUANTITY.findall(sent)
            if qs:
                add("quantity", entity_name, "states_quantity", ", ".join(qs[:4]), sent, 0.75)
                fired = True

            if COMPARISON.search(sent):
                add("comparison", entity_name, "compares", sent, sent, 0.65)
                fired = True

            if CREDENTIAL.search(sent):
                add("credential", entity_name, "claims_credential",
                    CREDENTIAL.search(sent).group(0), sent, 0.7)
                fired = True

            for q in QUOTE.findall(sent):
                add("quote", entity_name, "quotes", q, sent, 0.6)
                fired = True

            if not fired and tag in ("p", "li") and len(sent) > 40:
                add("attribute", entity_name, "asserts", sent, sent, 0.4)

    if ordered_steps >= 3:
        add("process", entity_name, "has_steps", f"{ordered_steps} ordered steps",
            f"{ordered_steps} step-like list items", 0.6)

    return claims


def _iter_ld(node):
    if isinstance(node, dict):
        if "@graph" in node:
            for n in node["@graph"]:
                yield from _iter_ld(n)
        yield node
        for v in node.values():
            if isinstance(v, (dict, list)):
                yield from _iter_ld(v)
    elif isinstance(node, list):
        for n in node:
            yield from _iter_ld(n)


# ---------------------------------------------------------------- findings


def find_contradictions(claims):
    """Same normalized quantity subject, different values."""
    out = []
    by_ctx = defaultdict(list)
    for c in claims:
        if c.type != "quantity":
            continue
        # context key = the non-numeric words around the number
        key = " ".join(sorted(set(
            w.lower() for w in re.findall(r"[a-zA-Z]{4,}", c.text_span)
        )))[:120]
        if key:
            by_ctx[key].append(c)
    for key, group in by_ctx.items():
        vals = {c.object for c in group}
        urls = {c.source_url for c in group}
        if len(vals) > 1 and len(urls) > 1:
            out.append({"context": key[:80], "values": sorted(vals)[:4],
                        "sources": sorted(urls)[:4]})
    return out[:15]


def find_orphans(pages, claims):
    inbound = defaultdict(int)
    for p in pages.values():
        for l in set(p.internal_links_out):
            if l != p.url:
                inbound[l] += 1
    high_value = defaultdict(int)
    for c in claims:
        if c.type in ("quantity", "quote", "definition", "credential", "process"):
            high_value[c.source_url] += 1
    return sorted(
        [{"url": u, "inbound_links": inbound.get(u, 0), "high_value_claims": n}
         for u, n in high_value.items() if inbound.get(u, 0) <= 1 and n >= 2],
        key=lambda d: -d["high_value_claims"],
    )[:15]


def find_duplicate_urls(pages):
    """Same body text served at >1 URL, with what each URL declared about it.

    Splits the entity's authority across URLs and gives engines competing
    candidates to cite. Surfaced by real input on the first live run.

    The canonical half is an OBSERVATION now. v0.5.0 printed "no canonical" on
    every group while never parsing the tag, which is a conclusion with nothing
    under it. Three outcomes are genuinely different and are kept apart:

      agree     every URL in the group points at the same target — already handled
      disagree  they point at different targets — worse than absence, because each
                URL is actively asserting itself as the original
      absent    none declared one — the case the old wording assumed universally
      partial   some declared, some did not
    """
    by_text = defaultdict(list)
    for p in pages.values():
        if p.word_count >= 50:
            key = re.sub(r"\s+", " ", p.body_text[:1500]).strip().lower()
            by_text[key].append(p)

    groups = []
    for members in by_text.values():
        if len(members) < 2:
            continue
        canonicals = {m.url: (m.canonical_resolved or m.canonical) for m in members}
        declared = [v for v in canonicals.values() if v]
        if not declared:
            status = "absent"
        elif len(declared) < len(members):
            status = "partial"
        elif len(set(declared)) == 1:
            status = "agree"
        else:
            status = "disagree"
        groups.append({
            "urls": sorted(canonicals),
            "count": len(members),
            "canonicals": canonicals,
            "canonical_status": status,
        })
    return groups[:15]


def find_unsourced_quantities(pages, claims):
    """Quantity claims on pages with no outbound external links = no citation."""
    out = []
    for c in claims:
        if c.type != "quantity":
            continue
        p = pages.get(c.source_url)
        if p and len(p.external_links_out) == 0:
            out.append({"claim": c.text_span[:140], "source": c.source_url})
    return out[:15]


# ---------------------------------------------------------------- crawl loop


def crawl(domain, max_pages=60, delay=0.4, verbose=True):
    if not domain.startswith("http"):
        domain = "https://" + domain
    parts = urllib.parse.urlsplit(domain)
    origin = f"{parts.scheme}://{parts.netloc}"
    host = parts.netloc

    blocked, sitemaps, restricted = check_robots(origin)

    queue, seen = [origin + "/"], set()
    for sm in sitemaps[:5]:
        for u in urls_from_sitemap(sm, origin):
            if u not in queue:
                queue.append(u)

    pages, order = {}, 0
    while queue and len(pages) < max_pages:
        url = normalize_url(queue.pop(0))
        if url in seen or SKIP_EXT.search(url):
            continue
        seen.add(url)

        status, ctype, body, final = fetch(url)
        if status != 200 or "html" not in ctype.lower():
            continue

        ex = Extractor()
        try:
            ex.feed(body)
            ex.close()
        except Exception:
            pass

        text = " ".join(t for tag, t in ex.blocks if tag in ("p", "li", "td", "dd", "blockquote"))
        pg = Page(
            url=url, status=status, title=ex.title.strip()[:200],
            meta_description=ex.meta_description[:300], lang=ex.lang,
            outline=ex.outline[:60], blocks=ex.blocks, body_text=text[:60000],
            schema_blocks=ex.schema_blocks, images_no_alt=ex.images_no_alt,
            word_count=len(text.split()),
            canonical=ex.canonical,
            canonical_resolved=(normalize_url(urllib.parse.urljoin(url, ex.canonical))
                                if ex.canonical else None),
        )
        pg.needs_headless = pg.word_count < 100 and ex.has_script

        for href in ex.links:
            try:
                absu = normalize_url(urllib.parse.urljoin(url, href))
            except Exception:
                continue
            if not absu.startswith("http"):
                continue
            if urllib.parse.urlsplit(absu).netloc == host:
                pg.internal_links_out.append(absu)
                if absu not in seen and len(pages) + len(queue) < max_pages * 4:
                    queue.append(absu)
            else:
                pg.external_links_out.append(absu)

        pages[url] = pg
        order += 1
        if verbose:
            flag = " [SPA?]" if pg.needs_headless else ""
            print(f"  [{order:>3}] {pg.word_count:>5}w  {url[:78]}{flag}", file=sys.stderr)
        time.sleep(delay)

    # entity inference — ordered by reliability
    home = pages.get(origin + "/") or (next(iter(pages.values())) if pages else None)

    def name_like(s):
        """Reject taglines/sentences. An entity name is a name, not a claim."""
        if not s:
            return False
        s = s.strip()
        return (2 < len(s) < 60 and len(s.split()) <= 6
                and ". " not in s and not s.endswith(".")
                and not s.endswith("?"))

    entity = host.split(".")[0]
    if home:
        # 1. schema.org Organization/Product name — highest confidence
        for block in home.schema_blocks:
            for node in _iter_ld(block):
                t = node.get("@type")
                t = t[0] if isinstance(t, list) and t else t
                if t in ("Organization", "Corporation", "LocalBusiness",
                         "Product", "SoftwareApplication", "WebSite"):
                    if name_like(node.get("name")):
                        entity = node["name"].strip()
                        break
            else:
                continue
            break
        else:
            # 2. leading segment of <title> before a separator
            cand = re.split(r"\s[–—|·:-]\s", home.title)[0].strip() if home.title else ""
            if name_like(cand):
                entity = cand
            else:
                # 3. an h1 only if it reads as a name, not a tagline
                for lvl, txt in home.outline:
                    if lvl == 1 and name_like(txt):
                        entity = txt.strip()
                        break

    seq = [0]
    claims = []
    for p in pages.values():
        claims.extend(extract_claims(p, entity, seq))

    return {
        **identity(),
        "domain": host, "origin": origin, "entity": entity,
        "robots_blocked_ai_crawlers": blocked, "robots_restricted": restricted,
        "sitemaps_found": sitemaps[:5],
        "pages": pages, "claims": claims,
        "findings": {
            "contradictions": find_contradictions(claims),
            "orphans": find_orphans(pages, claims),
            "duplicate_urls": find_duplicate_urls(pages),
            "unsourced_quantities": find_unsourced_quantities(pages, claims),
            "spa_pages": [p.url for p in pages.values() if p.needs_headless],
            "pages_without_schema": [p.url for p in pages.values() if not p.schema_blocks],
        },
    }


# ---------------------------------------------------------------- report


def build_parser():
    ap = argparse.ArgumentParser()
    ap.add_argument("domain")
    # Defaults are None so that "unspecified" is distinguishable from a value;
    # config.py holds the single application default.
    ap.add_argument("--max-pages", type=int, default=None)
    ap.add_argument("--delay", type=float, default=None)
    ap.add_argument("--json")
    return ap


def identity():
    """Stamped into every artifact so a corpus can prove it is internally consistent.

    No timestamp on purpose: identical inputs must regenerate byte-identically, and
    a clock in the output would make that impossible to check.
    """
    return {
        "alkeyword_version": VERSION,
        "crawl_schema": CRAWL_SCHEMA,
        "config_fingerprint": (cfg_mod.fingerprint() if cfg_mod else "no-config"),
        "robots_engine": robots_mod.ENGINE,
    }


def empty_result(host):
    """Identity-only result. Used by tests and by surfaces that returned nothing."""
    return {
        **identity(),
        "domain": host, "origin": "", "entity": "",
        "robots_blocked_ai_crawlers": [], "robots_restricted": {},
        "sitemaps_found": [], "pages": {}, "claims": [],
        "findings": {},
    }


def report(r):
    pages, claims = r["pages"], r["claims"]
    by_type = defaultdict(list)
    for c in claims:
        by_type[c.type].append(c)

    W = 74
    print("\n" + "=" * W)
    print(f"  ALKEYWORD — STAGE 1 CRAWL   ·   {r['domain']}")
    print("=" * W)
    print(f"  Entity inferred : {r['entity']}")
    print(f"  Pages crawled   : {len(pages)}")
    print(f"  Total words     : {sum(p.word_count for p in pages.values()):,}")
    print(f"  Claims extracted: {len(claims)}")
    print(f"  Sitemaps        : {len(r['sitemaps_found'])}")

    print("\n  CLAIM GRAPH BY TYPE")
    print("  " + "-" * (W - 4))
    order = ["entity", "quantity", "quote", "definition", "comparison",
             "question", "credential", "process", "attribute"]
    lever = {"quantity": " ← strongest citation lever",
             "quote": " ← 2nd strongest lever",
             "definition": " ← mintable: glossary",
             "comparison": " ← mintable: comparison page",
             "question": " ← mintable: FAQ",
             "process": " ← mintable: how-it-works"}
    for t in order:
        n = len(by_type.get(t, []))
        bar = "█" * min(38, n)
        print(f"  {t:<11} {n:>5}  {bar}{lever.get(t, '') if n else ''}")

    # material sufficiency (spec §4.2)
    print("\n  MATERIAL SUFFICIENCY — what could be minted (spec §4.2)")
    print("  " + "-" * (W - 4))
    q, qt, d, cmp_, ques, cred, proc = (
        len(by_type["quantity"]), len(by_type["quote"]), len(by_type["definition"]),
        len(by_type["comparison"]), len(by_type["question"]), len(by_type["credential"]),
        len(by_type["process"]),
    )
    forms = [
        ("Statistics / data page", q >= 5, f"{q}/5 quantity claims"),
        ("Glossary / definitions", d >= 3, f"{d}/3 definition claims"),
        ("FAQ page", ques >= 5, f"{ques}/5 question claims"),
        ("Comparison page", cmp_ >= 6, f"{cmp_}/6 comparison claims"),
        ("How-it-works explainer", proc >= 1, f"{proc}/1 process claims"),
        ("Entity / about page", cred >= 3, f"{cred}/3 credential claims"),
    ]
    for name, ok, detail in forms:
        print(f"  {'✓ MINTABLE' if ok else '✗ REFUSED '}  {name:<26} {detail}")

    f = r["findings"]
    print("\n  FREE FINDINGS — no engine calls spent (spec §1.7)")
    print("  " + "-" * (W - 4))
    # Tri-state, because the data model is. "does not block AI crawlers" was
    # printed whenever the blocked list was empty, which reads as "unrestricted"
    # even when a crawler can reach / but not /docs/. Absence of a total block is
    # not absence of restriction.
    blocked = r["robots_blocked_ai_crawlers"]
    restricted = r.get("robots_restricted") or {}
    if blocked:
        print(f"  ✗ {len(blocked)} AI crawler(s) cannot fetch the site root: "
              f"{', '.join(blocked)}")
    if restricted:
        print(f"  △ {len(restricted)} AI crawler(s) have path-scoped restrictions:")
        for agent, denied in sorted(restricted.items()):
            print(f"      {agent}: {', '.join(denied)}")
    if not blocked and not restricted:
        print("  ✓ no AI crawler restrictions observed on the probed paths")
    print(f"  · self-contradictions   : {len(f['contradictions'])}")
    print(f"  · duplicate-URL groups  : {len(f['duplicate_urls'])}")
    print(f"  · orphaned value pages  : {len(f['orphans'])}")
    print(f"  · unsourced quantities  : {len(f['unsourced_quantities'])}")
    print(f"  · SPA pages (need JS)   : {len(f['spa_pages'])}")
    print(f"  · pages with no schema  : {len(f['pages_without_schema'])}/{len(pages)}")

    if f["contradictions"]:
        print("\n  ⚠ CONTRADICTIONS (G6)")
        for c in f["contradictions"][:4]:
            print(f"    values {c['values']}  across {len(c['sources'])} pages")
            for s in c["sources"][:2]:
                print(f"      · {s[:68]}")

    if f["duplicate_urls"]:
        print("\n  ⚠ DUPLICATE CONTENT — same page, multiple URLs")
        for d in f["duplicate_urls"][:4]:
            print(f"    {d['count']} URLs serve identical content:")
            for u in d["urls"][:3]:
                print(f"      · {u[:66]}")

    if f["orphans"]:
        print("\n  ⚠ ORPHANED HIGH-VALUE PAGES (G7)")
        for o in f["orphans"][:5]:
            print(f"    {o['high_value_claims']:>3} claims · {o['inbound_links']} inbound · {o['url'][:56]}")

    print("\n  SAMPLE CLAIMS (highest-value types)")
    print("  " + "-" * (W - 4))
    for t in ("quantity", "definition", "quote", "credential"):
        for c in by_type.get(t, [])[:3]:
            print(f"  [{c.id}] {t:<10} conf={c.confidence:.2f}")
            print(f"        \"{c.text_span[:96]}\"")
            print(f"        ← {c.source_url[:64]}")
    print("=" * W + "\n")


def main():
    ap = build_parser()
    a = ap.parse_args()
    # None means "not supplied", so config can answer. A literal default here is
    # what let config.py say 40 while this said 60 and neither knew about it.
    a.max_pages = _cfg("crawl.max_pages", a.max_pages, 40)
    a.delay = _cfg("crawl.delay", a.delay, 0.4)

    print(f"crawling {a.domain} (max {a.max_pages} pages)...", file=sys.stderr)
    r = crawl(a.domain, a.max_pages, a.delay)
    report(r)

    if a.json:
        # Derived from the result rather than re-listed. This block used to
        # enumerate its own keys, which meant the on-disk shape was defined in a
        # second place — and the identity stamp added to the result silently never
        # reached the file. Serialise everything, transform only what needs it.
        out = dict(r)
        out.pop("origin", None)
        out["pages"] = [{k: v for k, v in asdict(p).items() if k != "body_text"}
                        for p in r["pages"].values()]
        out["claims"] = [asdict(c) for c in r["claims"]]
        with open(a.json, "w") as fh:
            json.dump(out, fh, indent=2)
        print(f"wrote {a.json}", file=sys.stderr)


if __name__ == "__main__":
    main()
